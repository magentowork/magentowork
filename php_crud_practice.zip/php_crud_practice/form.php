<?php include_once("Connection.php"); ?>
<?php 
if(isset($_GET['id']))
{
$id1 = $_GET['id']; 
//selecting the row from table
$sql1="Select * from demo where id = '".$id1."'";
$result=mysqli_query($conn,$sql1); 

$row1 = mysqli_fetch_array($result);
 }
?>
<html>
   <head>
      <title>Crud Module</title>
   </head>
   <body>
   <?php 
        if($row1 == ''){
            echo "<h1>Insert form</h1>";
        }
        else{
            echo "<h1>Update form</h1>";
        }    
    ?>
      <form method="POST">
         <h1>Name:</h1>
         <input type="text" name="name" value="<?php echo $row1["name"]; ?>"  />
         <h1>title:</h1>
         <input type="text" name="title" value="<?php echo $row1["title"];?>" />
         <input type ="hidden" name ="id"  value="<?php echo $row1["id"];?>" />
         <input type="submit" />            
      </form>
      <table border="1px">
         <thead>
            <tr>
               <th>Name</th>
               <th>title</th>
               <th>Action</th>
            </tr>   
         </thead>
         <tbody>
            <?php
               $sql="Select * from demo";
               $result=mysqli_query($conn,$sql);
               
               if (!$result) {
                    printf("Error: %s\n", mysqli_error($conn));
               exit();
               }
               
               while($row = mysqli_fetch_array($result))
               {
               echo "<tr>";
               
               echo "<td>" . $row['name'] . "</td>";
               echo "<td>" . $row['title'] . "</td>";
               echo "<td><a href=\"form.php?delete_id=$row[id]\">delete</a> &nbsp; &nbsp;
               
               <a href=\"form.php?id=$row[id]\">update</a>
               </td>";
               echo "</tr>";
               echo "</tr>";
               }
               ?> 
         </tbody>
      </table>
   </body>
</html>
<?php
    if(isset($_GET['delete_id']))
    {
    $id = $_GET['delete_id'];
     
    //deleting the row from table
    $sql = "DELETE FROM demo WHERE id='".$id."'";
    $result=mysqli_query($conn,$sql);
    if($result)
    {
        echo "deleted succesfully";
    }
    }

   if($_SERVER["REQUEST_METHOD"] == "POST"){

    if($_POST["id"]!='')
    {
        if (isset($_POST["name"]) && isset($_POST["title"]))
		{
			$cname=$_POST["name"];
			$cdesc=$_POST["title"];
				
			if($cname!='' && $cdesc!='')
			{				
				$sql="update demo set name='".$cname."',title='".$cdesc."' where id = '".$id1."'";
				$result=mysqli_query($conn,$sql); 
				if($result)
				{
					echo "data updated successfully";
				}
			}
        }	
    }
    else {

        if(isset($_POST["name"])&& isset($_POST["title"])){
   
            $empname = $_POST["name"];
            $emptitle = $_POST["title"];
    
            if($empname !='' && $emptitle != '')
            {
                $sql = "insert into demo(name,title) values('".$empname."','".$emptitle."')";
                $result = mysqli_query($conn,$sql);
    
                if($result)
                {
                    echo "data inserted succesfully";
                }
            }
    
        }
    }
   }
   ?>
</html>