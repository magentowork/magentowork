<?php include_once("Connection.php"); ?>

<html>
   <head>
      <title>Crud Module</title>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script>
        $(document).ready(function(){
              $("#formsub").click(function(){

                $(".hello").append('<input type="text" name="title[]" />');
              
              });
        });
</script>
   </head>
   <body>
      <form method="POST">
         <h1>Name:</h1>
         <input type="text" name="name" />
         <h1>title:</h1>
         <input type="text" name="title[]" />
         <input type="button" value="add" id="formsub">

         <div class="hello"></div>
         <input type ="hidden" name ="id" />
         <input type="submit" />            
      </form>
      <table border="1px">
         <thead>
            <tr>
               <th>Name</th>
               <th>title</th>
               <th>Action</th>
            </tr>   
         </thead>
         <tbody>
            <?php
               $sql="Select * from demo";
               $result=mysqli_query($conn,$sql);
               
               if (!$result) {
                    printf("Error: %s\n", mysqli_error($conn));
               exit();
               }
               
               while($row = mysqli_fetch_array($result))
               {
               echo "<tr>";
               
               echo "<td>" . $row['name'] . "</td>";
               echo "<td>" . $row['title'] . "</td>";
               echo "<td><a href=\"form.php?delete_id=$row[id]\">delete</a> &nbsp; &nbsp;
               
               <a href=\"form.php?id=$row[id]\">update</a>
               </td>";
               echo "</tr>";
               echo "</tr>";
               }
               ?> 
         </tbody>
      </table>
   </body>
</html>
<?php

   if($_SERVER["REQUEST_METHOD"] == "POST"){


        if(isset($_POST["name"])&& isset($_POST["title"])){
   
            $empname = $_POST["name"];
            $emptitle = $_POST["title"];

           
            if($empname !='' && $emptitle != '')
            {
                $sql = "insert into demo(name,title) values('".$empname."','".$emptitle."')";
                $result = mysqli_query($conn,$sql);
    
                if($result)
                {
                    echo "data inserted succesfully";
                }
            }

        
    
   }
}
   ?>
</html>

