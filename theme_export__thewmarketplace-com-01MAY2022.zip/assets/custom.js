$(document).ready(function(){
  
  
$(".store-policy-wrappe .seller-info span#contact_modal").appendTo( ".seller-info" );
  
$(".seller-details  .wk-seller-logo" ).appendTo( ".seller-details-main" );
  
 $(".hide-reviews-only").click(function(){
  $(".product-page-reviews .spr-content").slideUp(250);
  $(".hide-reviews-only").hide();
  $(".show-reviews-only").show();
});
  
  
$(".show-reviews-only").click(function(){
  $(".product-page-reviews .spr-content").slideToggle(250);
  $(".hide-reviews-only").show();
  $(".show-reviews-only").hide();
});

  
  
  
  
if($(window).width() < 767){
// $(".footer_menu_wrap .footer-item h4").click(function(){
//   $(this).next(".footer-links").slideToggle(250); 
//   $(".footer_menu_wrap .footer-item h4").toggleClass("active");
// });
  
  $(".footer_menu_wrap .footer-item h4").on("click", function() {
    if ($(this).hasClass("active")) {
      $(this).removeClass("active");
      $(this)
        .siblings(".footer-links")
        .slideUp(200);      
    } else {
      $(".footer_menu_wrap .footer-item h4").removeClass("active");
      $(this).addClass("active");
      $(".footer-links").slideUp(200);
      $(this)
        .siblings(".footer-links")
        .slideDown(200);
    }
  });

}
  
  
  
  
  var oldText = $("span.variant-quantity").text(); 
  if(typeof oldText !== 'undefined' && oldText != ''){
      $("span.variant-quantity").text(oldText.replace('There are no products left', 'Sold out'));  
  }
  
  var oldText = $("span.variant-quantity").text(); 
  if(typeof oldText !== 'undefined' && oldText != ''){
      $("span.variant-quantity").text(oldText.replace('There are', 'Only'));  
  }
  var newText = $("span.variant-quantity").text();  
  if(typeof newText !== 'undefined' && newText != ''){
  	  $("span.variant-quantity").text(newText.replace('products left', 'left'));
  }
  
  
  var onlyCount = '';
  var reviwCountTxt = $('.spr-summary-actions-togglereviews').clone().html();
  if(reviwCountTxt){
  	var onlyCount = reviwCountTxt.replace(/[^0-9]/g,'');
  }
  var rCount = '<span class="review_count_custom">'+onlyCount+'</span>';
  
  if(!onlyCount) {    
  	$('.show-reviews-only').remove();
    $('.hide-reviews-only').remove();
  }
  
  
  setTimeout(function() {
    if(rCount) {    
  		$(rCount).insertBefore("h2.spr-header-title");
    }    
    
  }, 4000);
  
  
  

//    $(".main-menu ul li.menu-link:has(ul)").addClass("parent");
  
//     $(".toggle").click(function(){
//         $("nav.primary-menu > ul").slideToggle(250);
//         $(".toggle").toggleClass("active");
//         $("body").toggleClass("active");
//     });
  
    
    $(".sidebar__responsive-handles").click(function(){
      $("body").addClass("active");
    });
  
//     $(".search-back").click(function(){ 
//       $(".header-search").removeClass("active");
//     });

//     if($(window).width() < 767){
//        $( ".header-topbar .custom_links li" ).appendTo( ".main-menu ul" );
      
      
//       $('nav.primary-menu ul li.parent > a').after('<a class="child-triggerm"></a>');
//       $("a.child-triggerm").click(function(){
//          $("ul.menu.dropdown-child").toggle(250); 
//          $("nav.primary-menu").addClass("mobile-click");
//       });
    
     
//     }
 
  
  
  
// $("a[href^='#']").on('click', function(e) {

//    // prevent default anchor click behavior
//    e.preventDefault();

//    // store hash
//    var hash = this.hash;

//    // animate
//    $('html, body').animate({
//        scrollTop: $(hash).offset().top
//      }, 1000, function(){

//        // when done, add hash to url
//        // (default click behaviour)
//        window.location.hash = hash;
//      }); 

// });
  
 
  //show/hide  add more title 
  var slideFound = $('.center').find(".product-item__caption").html();
  $('.heading-silder-title').hide();
  
  if(slideFound) {
  	$('.heading-silder-title').show();
  }
  
  
  
//   function truncateText(selector, maxLength) {
//     var element = document.querySelector(selector),
//       truncated = element.innerText;

//     if (truncated.length > maxLength) {
//       truncated = truncated.substr(0, maxLength) + '...';
//     }
//     return truncated;
//   }
  
//   setTimeout(function(){
//      var seller_description = truncateText('#wk_seller_description', 107);
      
//       if(seller_description){
        
//           $('#wk_seller_description').html(seller_description);
//       } 
//   }, 2000);   
  
 var s = $("html, body");
    $("#more_about_seller").click((function() {
        return s.animate({
            scrollTop: $($(this).attr("href")).offset().top - 135
        })
    }))
    
});





