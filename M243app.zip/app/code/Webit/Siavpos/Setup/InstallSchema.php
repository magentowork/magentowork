<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace Webit\Siavpos\Setup;

use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

/**
 * @codeCoverageIgnore
 */
class InstallSchema implements InstallSchemaInterface
{
    /**
     * {@inheritdoc}
     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)
     */
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;

        $installer->startSetup();

        $table = $installer->getConnection()
            ->newTable($installer->getTable('siavpos_transactions'))
            ->addColumn(
                'id',
                \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                null,
                ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
                'ID'
            )->addColumn(
	            'order_id',
	            \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
	            null,
	            ['unsigned' => true, 'nullable' => false, 'default' => '0'],
	            'Order Id'
        	)->addColumn(
	            'order_status',
	            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
	            50,
	            ['nullable' => false, 'default' => false],
	            'Order Status'
	        )->addColumn(
	            'cc_installments',
	            \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
	            null,
	            [],
	            'Installments'
	        )->addColumn(
	            'amount',
	            \Magento\Framework\DB\Ddl\Table::TYPE_DECIMAL,
	            '12,4',
	            [],
	            'Order Total'
	        )->addColumn(
	            'txn_id',
	            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
	            100,
	            [],
	            'Transaction Id'
	        )->addColumn(
	            'txn_status',
	            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
	            100,
	            [],
	            'Transaction Status'
	        )->addColumn(
	            'paymentRef',
	            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
	            100,
	            [],
	            'Txn Id'
	        )->addColumn(
	            'payMethod',
	            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
	            100,
	            [],
	            'Payment Method'
	        )->addColumn(
	            'message',
	            \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
	            100,
	            [],
	            'Message'
	        )->addColumn(
	            'created_at',
	            \Magento\Framework\DB\Ddl\Table::TYPE_TIMESTAMP,
	            null,
	            ['nullable' => false, 'default' => \Magento\Framework\DB\Ddl\Table::TIMESTAMP_INIT],
	            'Created At'
	        )->setComment(
	            'Sia Virtual POS Transaction Table'
	        );

	        $installer->getConnection()->createTable($table);
    }
}