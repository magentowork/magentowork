<?php
namespace Webit\Siavpos\Setup;
use Magento\Framework\Setup\UpgradeSchemaInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\Setup\ModuleContextInterface;
class UpgradeSchema implements UpgradeSchemaInterface
{
    /**
     * Upgrades Tables
     *
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     * @return void
     */
    public function upgrade(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $setup->startSetup();
        if (version_compare($context->getVersion(), '1.0.0', '<')) {
            $setup->getConnection()
                ->addColumn(
                    $setup->getTable('quote_address'),
                    'fee_amount',
                    [
                        'type' => \Magento\Framework\DB\Ddl\Table::TYPE_DECIMAL,
                        '10,2',
                        'default' => 0.00,
                        'nullable' => true,
                        'comment' =>'Fee Amount'
                    ]
                );
            $setup->getConnection()
                ->addColumn(
                    $setup->getTable('quote_address'),
                    'base_fee_amount',
                    [
                        'type' => \Magento\Framework\DB\Ddl\Table::TYPE_DECIMAL,
                        '10,2',
                        'default' => 0.00,
                        'nullable' => true,
                        'comment' =>'Base Fee Amount'
                    ]
                );

            $setup->getConnection()
                ->addColumn(
                    $setup->getTable('sales_order'),
                    'fee_amount',
                    [
                        'type' => \Magento\Framework\DB\Ddl\Table::TYPE_DECIMAL,
                        '10,2',
                        'default' => 0.00,
                        'nullable' => true,
                        'comment' =>'Fee Amount'
                    ]
                );
            $setup->getConnection()
                ->addColumn(
                    $setup->getTable('sales_order'),
                    'base_fee_amount',
                    [
                        'type' => \Magento\Framework\DB\Ddl\Table::TYPE_DECIMAL,
                        '10,2',
                        'default' => 0.00,
                        'nullable' => true,
                        'comment' =>'Base Fee Amount'
                    ]
                );
            $setup->getConnection()
                ->addColumn(
                    $setup->getTable('sales_order'),
                    'fee_amount_refunded',
                    [
                        'type' => \Magento\Framework\DB\Ddl\Table::TYPE_DECIMAL,
                        '10,2',
                        'default' => 0.00,
                        'nullable' => true,
                        'comment' =>'Base Fee Amount Refunded'
                    ]
                );
            $setup->getConnection()
                ->addColumn(
                    $setup->getTable('sales_order'),
                    'base_fee_amount_refunded',
                    [
                        'type' => \Magento\Framework\DB\Ddl\Table::TYPE_DECIMAL,
                        '10,2',
                        'default' => 0.00,
                        'nullable' => true,
                        'comment' =>'Base Fee Amount Refunded'
                    ]
                );
            $setup->getConnection()
                ->addColumn(
                    $setup->getTable('sales_order'),
                    'fee_amount_invoiced',
                    [
                        'type' => \Magento\Framework\DB\Ddl\Table::TYPE_DECIMAL,
                        '10,2',
                        'default' => 0.00,
                        'nullable' => true,
                        'comment' =>'Fee Amount Invoiced'
                    ]
                );
            $setup->getConnection()
                ->addColumn(
                    $setup->getTable('sales_order'),
                    'base_fee_amount_invoiced',
                    [
                        'type' => \Magento\Framework\DB\Ddl\Table::TYPE_DECIMAL,
                        '10,2',
                        'default' => 0.00,
                        'nullable' => true,
                        'comment' =>'Base Fee Amount Invoiced'
                    ]
                );

            $setup->getConnection()
                ->addColumn(
                    $setup->getTable('sales_invoice'),
                    'fee_amount',
                    [
                        'type' => \Magento\Framework\DB\Ddl\Table::TYPE_DECIMAL,
                        '10,2',
                        'default' => 0.00,
                        'nullable' => true,
                        'comment' =>'Fee Amount'
                    ]
                );
            $setup->getConnection()
                ->addColumn(
                    $setup->getTable('sales_invoice'),
                    'base_fee_amount',
                    [
                        'type' => \Magento\Framework\DB\Ddl\Table::TYPE_DECIMAL,
                        '10,2',
                        'default' => 0.00,
                        'nullable' => true,
                        'comment' =>'Base Fee Amount'
                    ]
                );

            $setup->getConnection()
                ->addColumn(
                    $setup->getTable('sales_creditmemo'),
                    'fee_amount',
                    [
                        'type' => \Magento\Framework\DB\Ddl\Table::TYPE_DECIMAL,
                        '10,2',
                        'default' => 0.00,
                        'nullable' => true,
                        'comment' =>'Fee Amount'
                    ]
                );
            $setup->getConnection()
                ->addColumn(
                    $setup->getTable('sales_creditmemo'),
                    'base_fee_amount',
                    [
                        'type' => \Magento\Framework\DB\Ddl\Table::TYPE_DECIMAL,
                        '10,2',
                        'default' => 0.00,
                        'nullable' => true,
                        'comment' =>'Base Fee Amount'
                    ]
                );
        }
        

        if (version_compare($context->getVersion(), '1.0.2', '<')) {
            $this->modifySalesOrderColumns($setup);
        }
		
        if (version_compare($context->getVersion(), '1.0.6', '<')) {
            $setup->getConnection()->addColumn(
                    $setup->getTable('siavpos_transactions'),
                    'oid',
                    [
                        'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                        'nullable' => true,
						'length' => '200',
						'comment' =>'Order Id Long'
                    ]
                );
			$setup->getConnection()
                ->addColumn(
                    $setup->getTable('siavpos_transactions'),
                    'mref',
                    [
                        'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                        'nullable' => true,
						'length' => '150',
						'comment' =>'Merchant Reference'
                    ]
                );
			$setup->getConnection()
                ->addColumn(
                    $setup->getTable('siavpos_transactions'),
                    'currency',
                    [
                        'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                        'nullable' => true,
						'length' => '3',
						'comment' =>'Currency'
                    ]
                );	
			$setup->getConnection()
                ->dropColumn(
                    $setup->getTable('siavpos_transactions'),
                    'created_at',
                    []
                );
			$setup->getConnection()
                ->addColumn(
                    $setup->getTable('siavpos_transactions'),
                    'created_at',
                    [
                        'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TIMESTAMP,
                        'nullable' => true,
						'comment' =>'Created At'
                    ]
                );
			$setup->getConnection()
                ->addColumn(
                    $setup->getTable('siavpos_transactions'),
                    'updated_at',
                    [
                        'type' => \Magento\Framework\DB\Ddl\Table::TYPE_TIMESTAMP,
                        'nullable' => true,
						'comment' =>'Updated At'
                    ]
                );		

        }
				
        $setup->endSetup();
    }

    public function modifySalesOrderColumns($setup){
        $setup->getConnection()
            ->modifyColumn(
                $setup->getTable('quote_address'),
                'fee_amount',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_DECIMAL,
                    'nullable' => true,
                    'length' => '12,4',
                    'comment' =>'Fee Amount'
                ]
            );
        $setup->getConnection()
            ->modifyColumn(
                $setup->getTable('quote_address'),
                'base_fee_amount',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_DECIMAL,
                    'nullable' => true,
                    'length' => '12,4',
                    'comment' =>'Base Fee Amount'
                ]
            );

        $setup->getConnection()
            ->modifyColumn(
                $setup->getTable('sales_order'),
                'fee_amount',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_DECIMAL,
                    'nullable' => true,
                    'length' => '12,4',
                    'comment' =>'Fee Amount'
                ]
            );
        $setup->getConnection()
            ->modifyColumn(
                $setup->getTable('sales_order'),
                'base_fee_amount',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_DECIMAL,
                    'nullable' => true,
                    'length' => '12,4',
                    'comment' =>'Base Fee Amount'
                ]
            );
        $setup->getConnection()
            ->modifyColumn(
                $setup->getTable('sales_order'),
                'fee_amount_refunded',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_DECIMAL,
                    'nullable' => true,
                    'length' => '12,4',
                    'comment' =>'Fee Amount Refunded'
                ]
            );
        $setup->getConnection()
            ->modifyColumn(
                $setup->getTable('sales_order'),
                'base_fee_amount_refunded',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_DECIMAL,
                    'nullable' => true,
                    'length' => '12,4',
                    'comment' =>'Base Fee Amount Refunded'
                ]
            );
        $setup->getConnection()
            ->modifyColumn(
                $setup->getTable('sales_order'),
                'fee_amount_invoiced',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_DECIMAL,
                    'nullable' => true,
                    'length' => '12,4',
                    'comment' =>'Fee Amount Invoiced'
                ]
            );
        $setup->getConnection()
            ->modifyColumn(
                $setup->getTable('sales_order'),
                'base_fee_amount_invoiced',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_DECIMAL,
                    'nullable' => true,
                    'length' => '12,4',
                    'comment' =>'Base Fee Amount Invoiced'
                ]
            );

        $setup->getConnection()
            ->modifyColumn(
                $setup->getTable('sales_invoice'),
                'fee_amount',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_DECIMAL,
                    'nullable' => true,
                    'length' => '12,4',
                    'comment' =>'Fee Amount'
                ]
            );
        $setup->getConnection()
            ->modifyColumn(
                $setup->getTable('sales_invoice'),
                'base_fee_amount',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_DECIMAL,
                    'nullable' => true,
                    'length' => '12,4',
                    'comment' =>'Base Fee Amount'
                ]
            );

        $setup->getConnection()
            ->modifyColumn(
                $setup->getTable('sales_creditmemo'),
                'fee_amount',
                [
                   'type' => \Magento\Framework\DB\Ddl\Table::TYPE_DECIMAL,
                    'nullable' => true,
                    'length' => '12,4',
                    'comment' =>'Fee Amount'
                ]
            );
        $setup->getConnection()
            ->modifyColumn(
                $setup->getTable('sales_creditmemo'),
                'base_fee_amount',
                [
                    'type' => \Magento\Framework\DB\Ddl\Table::TYPE_DECIMAL,
                    'nullable' => true,
                    'length' => '12,4',
                    'comment' =>'Base Fee Amount'
                ]
            );
        
    }
}