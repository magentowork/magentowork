Copyright 2020  Webit.bz
http://www.webit.bz
License: http://www.webit.bz/license.txt

INSTALLATION:
1 - unzip the package in your Magento installation, only new files will be added to the app/code/Webit/Siavpos folder
2 - enable module: bin/magento module:enable --clear-static-content Webit_Siavpos
3 - upgrade database: bin/magento setup:upgrade
4 - flush command: bin/magento cache:flush
5 - compile command: bin/magento setup:di:compile

In order to deactivate the module bin/magento module:disable --clear-static-content Webit_Siavpos
In order to update static files: bin/magento setup:static-content:deploy
