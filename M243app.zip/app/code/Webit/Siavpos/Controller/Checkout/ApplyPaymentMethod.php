<?php
/**
 *
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Webit\Siavpos\Controller\Checkout;

class ApplyPaymentMethod extends \Magento\Framework\App\Action\Action
{
    /**
    * @var \Magento\Checkout\Model\Session
    */
    protected $_checkoutSession;


    protected $_resultPageFactory;

    
    /**
    * @param \Magento\Framework\App\Action\Context $context
    * @param \Magento\Checkout\Model\Session $checkoutSession
    */
    public function __construct(
    \Magento\Framework\App\Action\Context $context,
    \Magento\Checkout\Model\Session $checkoutSession,
    \Magento\Framework\View\Result\PageFactory $resultPageFactory
    ) {
        $this->_checkoutSession = $checkoutSession;
        $this->_resultPageFactory = $resultPageFactory;
        parent::__construct($context);
    }

    /**
     * Retrieve params and put javascript into iframe
     *
     * @return void
     */
    public function execute()
    {
        $this->_checkoutSession->unsFee();

        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $scopeConfig = $objectManager->create('\Magento\Framework\App\Config\ScopeConfigInterface');
        $extra_fee = $scopeConfig->getValue('payment/attpay/extra_fee');
        $paymentMethod = $this->getRequest()->getParam('payment_method');
        $installment = $this->getRequest()->getParam('installments');

        if($paymentMethod=='attpay'){
            if(isset($extra_fee) && $extra_fee!=''){
        
                $instal_charge = [];
                $split_instal_charge = explode(',', $extra_fee);
                $qtotal = $this->getQuote()->getGrandTotal();
                
                $this->_checkoutSession->setFee(0);
                $c = count ($split_instal_charge);

                for($i=0; $i<$c; $i++)
                {
                    list($duration, $charge) = explode(":", $split_instal_charge[$i]);
                
                    if($installment == $duration){
                        $attpay_percentage = $qtotal*($charge/100);
                        $attpay_amount = round($attpay_percentage, 2);
                        $this->_checkoutSession->setFee($attpay_amount);
                       
                    }
                }
            }
        }else{
            $this->_checkoutSession->unsFee();
           // echo 0;
        }
        echo $this->_checkoutSession->getFee();
        
    }

    public function getQuote()
    {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        return $objectManager->get('\Magento\Checkout\Model\Session')->getQuote();
    }
}