<?php
/**
 *
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);  //mag23 
 
namespace Webit\Siavpos\Controller\Attpay;

use Magento\Framework\App\CsrfAwareActionInterface; //mag23
use Magento\Framework\App\Request\InvalidRequestException; //mag23
use Magento\Framework\App\RequestInterface; //mag23

class Success extends \Magento\Framework\App\Action\Action implements CsrfAwareActionInterface  //mag23 (implements)
{
    /**
    * @var \Magento\Checkout\Model\Session
    */
    protected $_checkoutSession;
    protected $_resultPageFactory;
	protected $_orderSender;
	
	/**
    * Post request array from Bank
    * @var array
    */
	private  $_siavposResponse;
    
    /**
    * @param \Magento\Framework\App\Action\Context $context
    * @param \Magento\Checkout\Model\Session $checkoutSession
    */
    public function __construct(
    \Magento\Framework\App\Action\Context $context,
    \Magento\Checkout\Model\Session $checkoutSession,
	\Magento\Sales\Model\Order\Email\Sender\OrderSender $orderSender,
    \Magento\Framework\View\Result\PageFactory $resultPageFactory
    ) {
        $this->_checkoutSession = $checkoutSession;
		$this->_orderSender = $orderSender;
        $this->_resultPageFactory = $resultPageFactory;
        parent::__construct($context);
    }
    
    /**
     * Retrieve params and put javascript into iframe
     *
     * @return void
     */
    public function execute()
    {

        $session = $this->_checkoutSession;

        $session->setAttpayQuoteId($session->getQuoteId());
    
         if ($this->getRequest()->getParam('ORDERID')) {
  
		  null !== $this->getRequest()->getParam('ORDERID') ? $ORDERID = addslashes($this->getRequest()->getParam('ORDERID')) : $ORDERID = '';
		  null !== $this->getRequest()->getParam('SHOPID') ? $SHOPID = addslashes($this->getRequest()->getParam('SHOPID')) : $SHOPID = '';
		  null !== $this->getRequest()->getParam('AUTHNUMBER') ? $AUTHNUMBER = addslashes($this->getRequest()->getParam('AUTHNUMBER')) : $AUTHNUMBER = '';
		  null !== $this->getRequest()->getParam('AMOUNT') ? $AMOUNT = addslashes($this->getRequest()->getParam('AMOUNT')) : $AMOUNT = '';
		  null !== $this->getRequest()->getParam('CURRENCY') ? $CURRENCY = addslashes($this->getRequest()->getParam('CURRENCY')) : $CURRENCY = '';
		  null !== $this->getRequest()->getParam('TRANSACTIONID') ? $TRANSACTIONID = addslashes($this->getRequest()->getParam('TRANSACTIONID')) : $TRANSACTIONID = '';
		  null !== $this->getRequest()->getParam('ACCOUNTINGMODE') ? $ACCOUNTINGMODE = addslashes($this->getRequest()->getParam('ACCOUNTINGMODE')) : $ACCOUNTINGMODE = '';
		  null !== $this->getRequest()->getParam('AUTHORMODE') ? $AUTHORMODE = addslashes($this->getRequest()->getParam('AUTHORMODE')) : $AUTHORMODE = '';
		  null !== $this->getRequest()->getParam('RESULT') ? $RESULT = addslashes($this->getRequest()->getParam('RESULT')) : $RESULT = '';
		  null !== $this->getRequest()->getParam('TRANSACTIONTYPE') ? $TRANSACTIONTYPE = addslashes($this->getRequest()->getParam('TRANSACTIONTYPE')) : $TRANSACTIONTYPE = '';
		  null !== $this->getRequest()->getParam('AUTHCODE') ? $AUTHCODE = addslashes($this->getRequest()->getParam('AUTHCODE')) : $AUTHCODE = '';
		  null !== $this->getRequest()->getParam('MAC') ? $MAC = addslashes($this->getRequest()->getParam('MAC')) : $MAC = '';
		  null !== $this->getRequest()->getParam('INSTALLMENTSNUMBER') ? $NUMRATE = addslashes($this->getRequest()->getParam('INSTALLMENTSNUMBER')) : $NUMRATE = '';
			
			$transaction = $this->_objectManager->create('Webit\Siavpos\Model\Siavpos')->load($ORDERID, 'mref' )->getData();
			$orderID = $transaction['oid'];
            $order = $this->_objectManager->create('\Magento\Sales\Model\Order');
            $order->loadByIncrementId($orderID);
			
			$update_transaction = $this->_objectManager->create('Webit\Siavpos\Model\Siavpos')->load($ORDERID, 'mref');
			
			if(isset($NUMRATE) && $NUMRATE != ''){
			 $macperiod='&INSTALLMENTSNUMBER='.$NUMRATE;
		   	} else {
			 $macperiod='';
		   	}
		  
		  $mac_check = strtoupper(hash_hmac('sha256','ORDERID='.$ORDERID.'&SHOPID='.$SHOPID.'&AUTHNUMBER='.$AUTHNUMBER.'&AMOUNT='.$AMOUNT.'&CURRENCY='.$CURRENCY.'&TRANSACTIONID='.$TRANSACTIONID.'&ACCOUNTINGMODE='.$ACCOUNTINGMODE.'&AUTHORMODE='.$AUTHORMODE.'&RESULT='.$RESULT.'&TRANSACTIONTYPE='.$TRANSACTIONTYPE.'&AUTHCODE='.$AUTHCODE.$macperiod.'',$this->getSiavposr()->getKeyResult(),false));
            
		if( strtoupper($MAC) == $mac_check && $RESULT=='00' && number_format(floatval($AMOUNT)) == number_format(round(floatval($transaction['amount'])*100)) && number_format(floatval($CURRENCY)) == number_format(floatval($transaction['currency'])) ){

			if(isset($transaction['order_status']) && $transaction['order_status']=='I'){ 
			
				$charge = number_format(floatval($transaction['amount']), 2, '.', '');
				$payment = $order->getPayment();

				if($this->getSiavposr()->getAccountingMode() == 'I'){
                    $payment->setTransactionId($TRANSACTIONID)
                    ->setParentTransactionId(null)
                     ->setIsTransactionClosed(1)
                    ->registerCaptureNotification($charge);
                } else {
                    $payment->setTransactionId($TRANSACTIONID)
                    ->setParentTransactionId(null)
                     ->setIsTransactionClosed(1)
                    ->registerAuthorizationNotification($charge);
                }

				$orderComment = 'Sia Virtual POS Confirmed Transaction<br />';
                $orderComment .= 'TXID: '.$TRANSACTIONID.'<br />';
				$orderComment .= 'Auth. Number: '.$AUTHNUMBER.'<br />';
				if($NUMRATE > 1){
				$orderComment .= 'Instalments:'.$NUMRATE.'<br />';
				}

                $newstatus='';
                $newstatus=$this->getSiavposr()->getOrderStatus();
            
                if(!isset($newstatus) || $newstatus == ''){
                    $newstatus = 'pending';
                }
                
                if($newstatus =='complete'){
                    $order->setData('state', "complete");
                    $order->setStatus("complete");
					$order->setBaseTotalPaid($charge); 
					$order->setTotalPaid($charge);
                    $history = $order->addStatusHistoryComment($orderComment, false);
                    $history->setIsCustomerNotified(true);

                } else {
                    $newstate = $newstatus;
                    $order->setData('state', $newstate);
                    $order->setStatus($newstate);
					$order->setBaseTotalPaid($charge); 
					$order->setTotalPaid($charge);
                    $history = $order->addStatusHistoryComment($orderComment, false);
                    $history->setIsCustomerNotified(true);
                }
				
                if ($order->canInvoice()) {
				
                        $order->getPayment()->setSkipTransactionCreation(false);
                        $invoice = $order->prepareInvoice();
                        $invoice->setRequestedCaptureCase(\Magento\Sales\Model\Order\Invoice::CAPTURE_ONLINE);
                        $invoice->register();

                        $transactionSave = $this->_objectManager->create(
                            'Magento\Framework\DB\Transaction'
                        )->addObject(
                            $invoice
                        )->addObject(
                            $order
                        )->save();
                }
            
                if($order->hasInvoices()){
                    $paid = \Magento\Sales\Model\Order\Invoice::STATE_PAID;
					
					$order->setBaseTotalInvoiced($charge);
					$order->setTotalInvoiced($charge);
                
                    foreach ($order->getInvoiceCollection() as $orderInvoice) {
                        $orderInvoice->setState($paid)
                                ->setTransactionId($TRANSACTIONID)
								->setBaseGrandTotal($charge)
								->setGrandTotal($charge)
                                ->save();
                    }
                }
			
                
                $order->save();
                $order->setCanSendNewEmailFlag(true)->setEmailSent(true)->save();
                $session->unsQuoteId(); 

				$update_transaction = $this->_objectManager->create('Webit\Siavpos\Model\Siavpos')->load($ORDERID, 'mref');
				$updated_data = ['order_status'=>'P', 'txn_id'=>$TRANSACTIONID, 'updated_at'=>date('Y-m-d h:i:s', time())];
                $update_transaction->addData($updated_data)->save();
				$this->_orderSender->send($order, true);
				}
                //return $this->_resultPageFactory->create();
				$this->_redirect('checkout/onepage/success', array('_secure'=>true));
            } else {
                if(isset($transaction['order_status']) && $transaction['order_status']=='I'){
				
				if(isset($RESULT) && $RESULT=='01'){
				 $msg = 'Denied by system';
				} elseif(isset($RESULT) && $RESULT=='02'){
				 $msg = 'Denied due to store configuration issues';
				} elseif(isset($RESULT) && $RESULT=='03'){
				 $msg = 'Denied due to communication issues with the authorization circuits';
				} elseif(isset($RESULT) && $RESULT=='04'){
				 $msg = 'Denied by card issuer';
				} elseif(isset($RESULT) && $RESULT=='05'){
				 $msg = 'Denied due to incorrect card number';
				} elseif(isset($RESULT) && $RESULT=='06'){
				 $msg = 'Unforeseen error during processing of request';
				} elseif(isset($RESULT) && $RESULT=='07'){
				 $msg = 'Duplicated order';
				} else {
				 $msg = 'Unknow error';
				}
			
				$updated_data = ['order_status'=>'F', 'message'=>$msg, 'updated_at'=>date('Y-m-d h:i:s', time())];
                $update_transaction->addData($updated_data)->save();
				$checkoutHelper = $this->_objectManager->create('Webit\Siavpos\Helper\Checkout');
				$orderComment = 'Transaction failed: '. $msg;
				$checkoutHelper->cancelCurrentOrder($orderComment);
				//https://github.com/magento/magento2/pull/12668/commits/2c1d6a4d115f1e97787349849d215e6c73ac1335
				$checkoutHelper->restoreQuote();
				}
                $this->messageManager->addErrorMessage(__('Your transaction failed or has been cancelled!'));
            	$this->_redirect('checkout/cart');
            }
        
        } else { 
            $this->_redirect('checkout/onepage/failure');
        }
    }


    public function getSiavposr()
    {
        return $this->_objectManager->create('Webit\Siavpos\Model\Attpay');
    }

    public function setSiavposResponse($response)
    {
        if (count($response)) {
            $this->_siavposResponse = $response;
        } else {
            $this->_siavposResponse = null;
        }
        return $this;
    }
	//mag23
    public function createCsrfValidationException(RequestInterface $request): ?InvalidRequestException
    {
        return null;
    }

	//mag23
    public function validateForCsrf(RequestInterface $request): ?bool
    {
        return true;
    }
}