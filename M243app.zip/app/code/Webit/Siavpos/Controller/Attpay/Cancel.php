<?php
/**
 *
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);  //mag23 
 
namespace Webit\Siavpos\Controller\Attpay;

use Magento\Framework\App\CsrfAwareActionInterface; //mag23
use Magento\Framework\App\Request\InvalidRequestException; //mag23
use Magento\Framework\App\RequestInterface; //mag23

class Cancel extends \Magento\Framework\App\Action\Action implements CsrfAwareActionInterface  //mag23 (implements)
{
    /**
    * @var \Magento\Checkout\Model\Session
    */
    protected $_checkoutSession;


    protected $_resultPageFactory;
    
    /**
    * @param \Magento\Framework\App\Action\Context $context
    * @param \Magento\Checkout\Model\Session $checkoutSession
    */
    public function __construct(
    \Magento\Framework\App\Action\Context $context,
    \Magento\Checkout\Model\Session $checkoutSession,
    \Magento\Framework\View\Result\PageFactory $resultPageFactory
    ) {
        $this->_checkoutSession = $checkoutSession;
        $this->_resultPageFactory = $resultPageFactory;
        parent::__construct($context);
    }

    /**
     * Retrieve params and put javascript into iframe
     *
     * @return void
     */
    public function execute()
    {
        $session = $this->_checkoutSession;
        $session->setQuoteId($session->getAttpayQuoteId(true));
        $this->_redirect('checkout/cart');
    }

	//mag23
    public function createCsrfValidationException(RequestInterface $request): ?InvalidRequestException
    {
        return null;
    }

	//mag23
    public function validateForCsrf(RequestInterface $request): ?bool
    {
        return true;
    }
	
}
