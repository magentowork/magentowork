<?php
/**
 *
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
declare(strict_types=1);  //mag23 
 
namespace Webit\Siavpos\Controller\Attpay;

use Magento\Framework\App\CsrfAwareActionInterface; //mag23
use Magento\Framework\App\Request\InvalidRequestException; //mag23
use Magento\Framework\App\RequestInterface; //mag23

class Fail extends \Magento\Framework\App\Action\Action implements CsrfAwareActionInterface  //mag23 (implements)
{
    /**
    * @var \Magento\Checkout\Model\Session
    */
    protected $_checkoutSession;
    protected $_resultPageFactory;
	
	/**
    * Post request array from Bank
    * @var array
    */
	private  $_siavposResponse;
    
    /**
    * @param \Magento\Framework\App\Action\Context $context
    * @param \Magento\Checkout\Model\Session $checkoutSession
    */
    public function __construct(
    \Magento\Framework\App\Action\Context $context,
    \Magento\Checkout\Model\Session $checkoutSession,
    \Magento\Framework\View\Result\PageFactory $resultPageFactory
    ) {
        $this->_checkoutSession = $checkoutSession;
        $this->_resultPageFactory = $resultPageFactory;
        parent::__construct($context);
    }

    /**
     * Retrieve params and put javascript into iframe
     *
     * @return void
     */
    public function execute()
    {

        $session = $this->_checkoutSession;
        $session->setAttpayQuoteId($session->getQuoteId());
    
        if ($this->getRequest()->getParam('ORDERID')) {
			
            $mref = addslashes($_GET['ORDERID']);
			$transaction = $this->_objectManager->create('Webit\Siavpos\Model\Siavpos')->load($mref, 'mref' )->getData();
	        $orderID = $transaction['oid'];

            if(isset($transaction['order_status']) && $transaction['order_status']!='F'){
			$order = $this->_objectManager->create('\Magento\Sales\Model\Order');
            $order->loadByIncrementId($orderID);

            $orderComment = 'Sia Virtual POS Cancelled Transaction';
			
			$update_transaction = $this->_objectManager->create('Webit\Siavpos\Model\Siavpos')->load($mref, 'mref');
            $updated_data = ['order_status'=>'F', 'updated_at'=>date('Y-m-d h:i:s', time())];
            $update_transaction->addData($updated_data)->save();
			
			$checkoutHelper = $this->_objectManager->create('Webit\Siavpos\Helper\Checkout');
			$checkoutHelper->cancelCurrentOrder($orderComment);
        	//https://github.com/magento/magento2/pull/12668/commits/2c1d6a4d115f1e97787349849d215e6c73ac1335
			$checkoutHelper->restoreQuote();
			}
            $this->messageManager->addErrorMessage(__('Your transaction failed or has been cancelled!'));
            $this->_redirect('checkout/cart');
        } else {
            $error_message = __('Your transaction failed or has been cancelled!');
            $this->messageManager->addErrorMessage($error_message);
            $this->_redirect('checkout/onepage/failure'); 
        }
        
    }

    public function setSiavposResponse($response)
    {
        if (count($response)) {
            $this->_siavposResponse = $response;
        } else {
            $this->_siavposResponse = null;
        }
        return $this;
    }

	//mag23
    public function createCsrfValidationException(RequestInterface $request): ?InvalidRequestException
    {
        return null;
    }

	//mag23
    public function validateForCsrf(RequestInterface $request): ?bool
    {
        return true;
    }
}
