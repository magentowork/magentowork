<?php
/**
 *
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Webit\Siavpos\Controller\Attpay;
use Magento\Framework\Controller\ResultFactory;

class Redirect extends \Magento\Framework\App\Action\Action
{
    /**
    * @var \Magento\Checkout\Model\Session
    */
    protected $_checkoutSession;


    protected $_resultPageFactory;
    
    /**
    * @param \Magento\Framework\App\Action\Context $context
    * @param \Magento\Checkout\Model\Session $checkoutSession
    */
    public function __construct(
    \Magento\Framework\App\Action\Context $context,
    \Magento\Checkout\Model\Session $checkoutSession,
    \Magento\Framework\View\Result\PageFactory $resultPageFactory,
    \Magento\Framework\Data\FormFactory $formFactory,
	\Magento\Framework\Controller\Result\RawFactory $resultRawFactory
    ) {
        $this->_checkoutSession = $checkoutSession;
        $this->_resultPageFactory = $resultPageFactory;
        $this->formFactory = $formFactory;
		$this->resultRawFactory = $resultRawFactory;		
        parent::__construct($context);
    }

    /**
     *
     * @return void
     */
    public function execute()
    {

            $session = $this->_checkoutSession;
        
            $session->setAttpayQuoteId($session->getQuoteId());
            $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
            $attpay = $objectManager->get('Webit\Siavpos\Model\Attpay');
            
            $form = $form = $this->formFactory->create();
            $form->setAction($attpay->getCgiUrl())
                ->setId('attpay_checkout')
                ->setName('attpay_checkout')
                ->setMethod('POST')
                ->setUseContainer(true);
            $form = $attpay->addSiavposFields($form);
                
            $html = '<html><body>';
            $html.= __('You will be redirected to Sia Virtual POS in a few seconds.');
            $html.= $form->toHtml();
            
            $html.= '<script type="text/javascript">document.getElementById("attpay_checkout").submit();</script>';
            $html.= '</body></html>';
            //echo $html;    
			
			/** @var \Magento\Framework\View\Result\Page $resultPage */
			$resultPage = $this->_resultPageFactory->create();
			$resultRaw = $this->resultRawFactory->create();
			$resultRaw->setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0', true);
			$resultRaw->setHeader('Pragma', 'no-cache', true);
			$resultRaw->setContents($html);
			return $resultRaw;    
    }

    /**
    * Get order object.
    *
    * @return \Magento\Sales\Model\Order
    */
    protected function getOrder()
    {
        return $this->_checkoutSession->getLastRealOrder();
    }
}