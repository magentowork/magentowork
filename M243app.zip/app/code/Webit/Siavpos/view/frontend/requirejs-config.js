var config = {
    map: {
        '*': {
            'Magento_Checkout/js/action/select-payment-method':
                'Webit_Siavpos/js/action/payment/select-payment-method'
        }
    }
};