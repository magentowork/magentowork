/**
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
/*browser:true*/
/*global define*/
define(
[
    'jquery',
    'Magento_Checkout/js/model/quote',
    'Magento_Checkout/js/view/payment/default',
    'Magento_Checkout/js/action/place-order',
    'Magento_Checkout/js/action/select-payment-method',
    'Magento_Customer/js/model/customer',
    'Magento_Checkout/js/checkout-data',
    'Magento_Checkout/js/model/payment/additional-validators',
    'Magento_Checkout/js/model/full-screen-loader',
    'Magento_Checkout/js/action/get-totals',
    'mage/url',
],
function (
    $,
    quote,
    Component,
    placeOrderAction,
    selectPaymentMethodAction,
    customer,
    checkoutData,
    additionalValidators,
    fullScreenLoader,
    getTotalsAction,
    url) {
        'use strict';

        return Component.extend({
            defaults: {
                template: 'Webit_Siavpos/payment/attpay',
                ccInstallments: ''
            },

            getCode: function() {
                return this.item.method;
            },

            placeOrder: function (data, event) {
                if (event) {
                    event.preventDefault();
                }
                var self = this,
                    placeOrder,
                    emailValidationResult = customer.isLoggedIn(),
                    loginFormSelector = 'form[data-role=email-with-possible-login]';
                if (!customer.isLoggedIn()) {
                    $(loginFormSelector).validation();
                    emailValidationResult = Boolean($(loginFormSelector + ' input[name=username]').valid());
                }
                if (emailValidationResult && this.validate() && additionalValidators.validate()) {
                    this.isPlaceOrderActionAllowed(false);
                    placeOrder = placeOrderAction(this.getData(), false, this.messageContainer);

                    $.when(placeOrder).fail(function () {
                        self.isPlaceOrderActionAllowed(true);
                    }).done(this.afterPlaceOrder.bind(this));
                    return true;
                }
                return false;
            },

            selectPaymentMethod: function() {
                selectPaymentMethodAction(this.getData());
                checkoutData.setSelectedPaymentMethod(this.item.method);
                return true;
            },

            afterPlaceOrder: function () {
                window.location.replace(url.build('siavposr/attpay/redirect'));
            },

            getInstructions: function() {
                return window.checkoutConfig.payment.instructions[this.item.method];
            },

            initObservable: function () {
                this._super()
                    .observe([
                        'ccInstallments'
                    ]);
                return this;
            },
            
            getData: function () {
                var parentReturn = this._super();
                if (parentReturn.additional_data === null) {
                    parentReturn.additional_data = {};
                }
                parentReturn.additional_data.cc_installments = this.ccInstallments();
               
                return parentReturn;
            },

            getCcInstallments: function () {
                return window.checkoutConfig.payment.siavpos.ccInstallments;
            },

            /** Returns payment acceptance mark image path */
            getPaymentMethodImageSrc: function() {
                return window.checkoutConfig.payment.siavpos.redirectAcceptanceMarkSrc;
            },

            addfee: function(){
               
                fullScreenLoader.startLoader();
                jQuery.ajax(url.build('siavposr/checkout/applyPaymentMethod'), {
                    data: {
                        payment_method: 'attpay',
                        installments: $('#attpay_cc_installments').val()
                    },
                    complete: function(data) {
                        jQuery("#fee").val(data.responseText);
                        getTotalsAction([]);
                        fullScreenLoader.stopLoader();
                    }
                });
            }

        });
    }
);
