define(
	[
		'Webit_Siavpos/js/view/checkout/cart/summary/fee'
	], function(Component) {
	    'use strict';
	    return Component.extend({
	        isDisplayed: function() {
	            return true;
	        }
	    });
	}
);