<?php
/**
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Webit\Siavpos\Model\Total;

class AtPayFee extends \Magento\Quote\Model\Quote\Address\Total\AbstractTotal
{
    /**
    * @var \Magento\Checkout\Model\Session
    */
    protected $_checkoutSession;
   /**
     * Collect grand total address amount
     *
     * @param \Magento\Quote\Model\Quote $quote
     * @param \Magento\Quote\Api\Data\ShippingAssignmentInterface $shippingAssignment
     * @param \Magento\Quote\Model\Quote\Address\Total $total
     * @return $this
     */
    protected $quoteValidator = null; 

    public function __construct(\Magento\Quote\Model\QuoteValidator $quoteValidator,
         \Magento\Checkout\Model\Session $checkoutSession)
    {

        $this->quoteValidator = $quoteValidator;
        $this->_checkoutSession = $checkoutSession;
    }
    public function collect(
        \Magento\Quote\Model\Quote $quote,
        \Magento\Quote\Api\Data\ShippingAssignmentInterface $shippingAssignment,
        \Magento\Quote\Model\Quote\Address\Total $total
    ) {
        parent::collect($quote, $shippingAssignment, $total);

        if(!$quote->getId()){
            $this->clearValues($total);
            $this->_checkoutSession->unsFee();
        }
        
        $atpay_fee = $this->_checkoutSession->getFee();
        if(!$atpay_fee){
            $atpay_fee = 0;
        }
        if($atpay_fee!=0){
            //$total->setTotalAmount('fee', $atpay_fee);
            //$total->setBaseTotalAmount('fee', $atpay_fee);
            $total->setFeeAmount($atpay_fee);
            $total->setBaseFeeAmount($atpay_fee);
            $quote->setFeeAmount($atpay_fee);
            $quote->setBaseFeeAmount($atpay_fee);
            //$total->setGrandTotal($total->getGrandTotal() + $atpay_fee);
            //$total->setBaseGrandTotal($total->getBaseGrandTotal() + $atpay_fee);
            //$this->_checkoutSession->unsFee();
        }else{
            $this->clearValues($total);
        }
        
        

        return $this;
    } 

    protected function clearValues(\Magento\Quote\Model\Quote\Address\Total $total)
    {
        $total->setTotalAmount('subtotal', 0);
        $total->setBaseTotalAmount('subtotal', 0);
        $total->setTotalAmount('tax', 0);
        $total->setBaseTotalAmount('tax', 0);
        $total->setTotalAmount('discount_tax_compensation', 0);
        $total->setBaseTotalAmount('discount_tax_compensation', 0);
        $total->setTotalAmount('shipping_discount_tax_compensation', 0);
        $total->setBaseTotalAmount('shipping_discount_tax_compensation', 0);
        $total->setSubtotalInclTax(0);
        $total->setBaseSubtotalInclTax(0);
    }
    /**
     * @param \Magento\Quote\Model\Quote $quote
     * @param Address\Total $total
     * @return array|null
     */
    /**
     * Assign subtotal amount and label to address object
     *
     * @param \Magento\Quote\Model\Quote $quote
     * @param Address\Total $total
     * @return array
     * @SuppressWarnings(PHPMD.UnusedFormalParameter)
     */
    public function fetch(\Magento\Quote\Model\Quote $quote, \Magento\Quote\Model\Quote\Address\Total $total)
    {
        //print_r($quote->getBaseGrandTotal());die("ppp");
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $url = $objectManager->create('\Magento\Framework\UrlInterface');
        $checkoutCart = $url->getUrl('checkout/cart/index');
        $checkout = $url->getUrl('checkout/index/index');
        $currentUrl = $url->getCurrentUrl();
        if(!$quote->getId()){
            $this->clearValues($total);
            $this->_checkoutSession->unsFee();
        }
        if($currentUrl==$checkoutCart){
            $atpay_fee=0;
        }else{
            $atpay_fee = $this->_checkoutSession->getFee();
        }
        
        if($atpay_fee>0){
            $total->setTotalAmount('fee', $atpay_fee);
            $total->setBaseTotalAmount('fee', $atpay_fee);

            $total->setFeeAmount($atpay_fee);
            $total->setBaseFeeAmount($atpay_fee);

            $quote->setFeeAmount($atpay_fee);
            $quote->setBaseFeeAmount($atpay_fee);

            $total->setGrandTotal($total->getGrandTotal() + $atpay_fee);
            $total->setBaseGrandTotal($total->getBaseGrandTotal() + $atpay_fee);
            

            //$this->_checkoutSession->unsFee();
            return [
                'code' => 'fee',
                'title' => $this->getLabel(),
                'value' => $atpay_fee
            ];
        }
        else{
                return [
                'code' => 'fee',
                'title' => $this->getLabel(),
                'value' => 0
            ];
        }

        $this->_checkoutSession->unsFee();
    }

    /**
     * Get Subtotal label
     *
     * @return \Magento\Framework\Phrase
     */
    public function getLabel()
    {
        return __('Payment Fee');
    }
}