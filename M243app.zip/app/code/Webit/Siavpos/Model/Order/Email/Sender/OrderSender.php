<?php
namespace Webit\Siavpos\Model\Order\Email\Sender;

use Magento\Sales\Model\Order;

class OrderSender extends \Magento\Sales\Model\Order\Email\Sender\OrderSender {

    public function send(Order $order, $forceSyncMode = false)
    {
        $payment = $order->getPayment()->getMethodInstance()->getCode();

        if($payment == 'attpay'){
          $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
			$transaction = $objectManager->create('Webit\Siavpos\Model\Siavpos')->load($order->getIncrementId(), 'order_id' )->getData();
			if((isset($transaction['order_status']) && $transaction['order_status']!='P') || !isset($transaction['order_status'])){
			 return false;
			}
         }
		 
		if($payment == 'attpayeb'){
          $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
			$transaction = $objectManager->create('Webit\Eurobnk\Model\Eurobnk')->load($order->getIncrementId(), 'order_id' )->getData();
			if((isset($transaction['order_status']) && $transaction['order_status']!='P') || !isset($transaction['order_status'])){
			 return false;
			}
         }
		 
		 if($payment == 'pscpay'){
			$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
			$transaction = $objectManager->create('Webit\Paysafecard\Model\Paysafecard')->load($order->getIncrementId(), 'order_id' )->getData();
			if((isset($transaction['order_status']) && $transaction['order_status']!='P') || !isset($transaction['order_status'])){
			 return false;
			}
        }
		
		if($payment == 'attpay'){
          $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
			$transaction = $objectManager->create('Webit\Siavpos\Model\Siavpos')->load($order->getIncrementId(), 'order_id' )->getData();
			if((isset($transaction['order_status']) && $transaction['order_status']!='P') || !isset($transaction['order_status'])){
			 return false;
			}
         }
		 
		 if($payment == 'jccpay'){
          $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
			$transaction = $objectManager->create('Webit\JccPayments\Model\JccPayments')->load($order->getIncrementId(), 'order_id' )->getData();
			if((isset($transaction['order_status']) && $transaction['order_status']!='P') || !isset($transaction['order_status'])){
			 return false;
			}
         }
		 
		  if($payment == 'hpspay'){
          $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
			$transaction = $objectManager->create('Webit\Nationalbnk\Model\Nationalbnk')->load($order->getIncrementId(), 'order_id' )->getData();
			if((isset($transaction['order_status']) && $transaction['order_status']!='P') || !isset($transaction['order_status'])){
			 return false;
			}
         }
		 
		 if($payment == 'nbg'){
          $objectManager = \Magento\Framework\App\ObjectManager::getInstance();

			$transaction = $objectManager->create('\Magento\Sales\Api\Data\TransactionSearchResultInterfaceFactory')->create()->addOrderIdFilter($order->getId())->getFirstItem();
			$transactionId = $transaction->getData('txn_id');
			
			if(!isset($transactionId) || $transactionId==''){
			 return false;
			}
         }
		 
		 if($payment == 'pirpay'){
          $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
			$transaction = $objectManager->create('Webit\Piraeusbnk\Model\Piraeusbnk')->load($order->getIncrementId(), 'order_id' )->getData();
			if((isset($transaction['order_status']) && $transaction['order_status']!='P') || !isset($transaction['order_status'])){
			 return false;
			}
         }

        $order->setSendEmail(true);

        if (!$this->globalConfig->getValue('sales_email/general/async_sending') || $forceSyncMode) {
            if ($this->checkAndSend($order)) {
                $order->setEmailSent(true);
                $this->orderResource->saveAttribute($order, ['send_email', 'email_sent']);
                return true;
            }
        }

        $this->orderResource->saveAttribute($order, 'send_email');

        return false;
    }
}