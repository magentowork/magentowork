<?php
namespace Webit\Siavpos\Model\Framework\Stdlib\Cookie;
use Magento\Framework\Stdlib\Cookie;

class PhpCookieManager extends \Magento\Framework\Stdlib\Cookie\PhpCookieManager {
protected function setCookie($name, $value, array $metadataArray){
}

}