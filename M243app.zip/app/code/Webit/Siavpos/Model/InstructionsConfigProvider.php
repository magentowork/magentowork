<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Webit\Siavpos\Model;

use Magento\Checkout\Model\ConfigProviderInterface;
use Magento\Framework\Escaper;
use Magento\Payment\Helper\Data as PaymentHelper;
use Magento\Payment\Model\CcConfig;

class InstructionsConfigProvider implements ConfigProviderInterface
{
    /**
     * @var string
     */
    protected $code = 'attpay';

    /**
     * @var \Magento\Payment\Model\Method\AbstractMethod[]
     */
    protected $methodCodes = [
        Attpay::PAYMENT_METHOD_SIAVPOS_CODE
    ];


    /**
     * @var Escaper
     */
    protected $escaper;

    /**
     * @param PaymentHelper $paymentHelper
     * @param Escaper $escaper
     */
    public function __construct(
        PaymentHelper $paymentHelper,
        Escaper $escaper
    ) {
        $this->escaper = $escaper;
        foreach ($this->methodCodes as $code) {
            $this->methods[$code] = $paymentHelper->getMethodInstance($code);
        }
    }

    /**
     * {@inheritdoc}
     */
    public function getConfig()
    {

        $config = [];
 		foreach ($this->methodCodes as $code) {
            if ($this->methods[$code]->isAvailable()) {
                $config['payment']['instructions'][$code] = $this->getInstructions($code);
            }
        }
        
        $config = array_merge_recursive($config, [
            'payment' => [
                'siavpos' => [
                    'ccInstallments' => $this->getCcInstallments(),
                    'redirectAcceptanceMarkSrc' => $this->getPaymentMethodImageUrl()
                    //'paymentFee' => $this->getPaymentFee()
                ]
            ]
        ]);

        return $config;
    }
    
    /**
     * Get instructions text from config
     *
     * @param string $code
     * @return string
     */
    protected function getInstructions($code)
    {
        return nl2br($this->escaper->escapeHtml($this->methods[$code]->getInstructions()));
    }


    public function getQuote()
    {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        return $objectManager->get('\Magento\Checkout\Model\Session')->getQuote();
    }
    
        
    public function getCcInstallments()
    {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $scopeConfig = $objectManager->create('\Magento\Framework\App\Config\ScopeConfigInterface');
        $instal_logic = $scopeConfig->getValue('payment/attpay/Installments');
		$display = false;
 
        if(isset($instal_logic) && $instal_logic!=''){
        
            $instal_eurobank = [];
            $split_instal_eurobank = explode(',', $instal_logic);
            $qtotal = $this->getQuote()->getBaseGrandTotal();

            $c = count ($split_instal_eurobank);

            for($i=0; $i<$c; $i++)
            {
                list($instal_amount, $instal_term) = explode(":", $split_instal_eurobank[$i]);
            
                if($qtotal >= $instal_amount){
                    $period_amount = round(($qtotal / $instal_term), 2);
                    $period_amount = number_format($period_amount, 2, '.', '');
                    $instal_eurobank[$instal_term] = $instal_term . __(' installments').'( ' . $instal_term . ' x '. $period_amount . ')' ;
					$display = true;
                }
            }

            $aReturn = [];
			
			if($display=='true'){
			$aReturn[] = [
                    'id' => '1',
                    'title' => 'No Installments',
                ];
				
            foreach ($instal_eurobank as $sKey => $sTitle) {
                $aReturn[] = [
                    'id' => $sKey,
                    'title' => $sTitle,
                ];
            }
            return $aReturn;
			}
        }
    }

    /**
     * Get PayPal "mark" image URL
     * Supposed to be used on payment methods selection
     * $staticSize is applicable for static images only
     *
     * @param string $localeCode
     * @param float|null $orderTotal
     * @param string|null $pal
     * @param string|null $staticSize
     * @return string
     */
    public function getPaymentMethodImageUrl($localeCode = '', $staticSize = null)
    {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $image = $objectManager->create('Magento\Payment\Model\CcConfig')->getViewFileUrl('Webit_Siavpos::images/siavpos.png');
        
        return sprintf(
            $image,
            $staticSize
        );
    }

/*    public function getPaymentFee(){
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $scopeConfig = $objectManager->create('\Magento\Framework\App\Config\ScopeConfigInterface');
        $feetype = $scopeConfig->getValue('payment/attpay/fee_type');
        $feeValue = $scopeConfig->getValue('payment/attpay/extra_fee');
        if($feetype == 'F'){
            return $feeValue;
        }else{
            $qtotal = $this->getQuote()->getBaseGrandTotal();

            $extra_fee = round($qtotal*($feeValue/100), 2);
            return $extra_fee;
        }
    }*/

}