<?php
namespace Webit\Siavpos\Model;

use Magento\Framework\DataObject;
use Magento\Sales\Api\Data\OrderPaymentInterface;
use Magento\Sales\Model\Order;
use Magento\Sales\Model\Order\Payment;
use Magento\Sales\Model\Order\Payment\Transaction;
use Magento\Quote\Model\Quote;
use Magento\Store\Model\ScopeInterface;
use Webit\Siavpos\Helper\DataConverter;

/**
 * Redirect payment method model
 */
class Attpay extends \Magento\Payment\Model\Method\AbstractMethod
{
    const PAYMENT_METHOD_SIAVPOS_CODE = 'attpay';
    const CODE = 'attpay';
    /**
     * Payment code
     *
     * @var string
     */
    protected $_code = self::CODE;

    /**
     * Availability option
     *
     * @var bool
     */
    protected $_isGateway = false;

    /**
     * Payment Method feature
     *
     * @var bool
     */
    protected $_canOrder = true;

    /**
     * Payment Method feature
     *
     * @var bool
     */
    protected $_canAuthorize = true;

    /**
     * Payment Method feature
     *
     * @var bool
     */
    protected $_canCapture = true;

    /**
     * Payment Method feature
     *
     * @var bool
     */
    protected $_isInitializeNeeded = true;

    /**
     * Availability option
     *
     * @var bool
     */
    protected $_canCapturePartial = true;

    /**
     * Availability option
     *
     * @var bool
     */
    protected $_canUseCheckout = true;

    /**
     * Availability option
     *
     * @var bool
     */
    protected $_canUseInternal = false;

    /**
     * Availability option
     *
     * @var bool
     */
    protected $_canFetchTransactionInfo = true;

    /**
     * Availability option
     *
     * @var bool
     */
    protected $_canRefund = true;

    /**
     * Availability option
     *
     * @var bool
     */
    protected $_canVoid = true;

    /**
     * Availability option
     *
     * @var bool
     */
    protected $_canReviewPayment = true;

    /**
     * Form block path
     *
     * @var string
     */
    protected $_infoBlockType = 'Webit\Siavpos\Block\Info\Instructions';
    /**
     * Info instructions block path
     *
     * @var string
     */
    //protected $_infoBlockType = 'Magento\Payment\Block\Info\Instructions';
	private $messageManager;
	private $dataConverter;

    public function __construct(
        \Magento\Framework\Model\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Api\ExtensionAttributesFactory $extensionFactory,
        \Magento\Framework\Api\AttributeValueFactory $customAttributeFactory,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Payment\Helper\Data $paymentData,
        \Magento\Framework\App\Config\ScopeConfigInterface $scopeConfig,
        \Magento\Payment\Model\Method\Logger $logger,
        \Magento\Checkout\Model\Session $checkoutSession,
        \Magento\Framework\Session\Generic $session,
        \Magento\Customer\Model\Session $customerSession,
        \Magento\Store\Api\Data\StoreInterface $store,
        \Magento\Framework\ObjectManagerInterface $objectManager,
        \Magento\Framework\UrlInterface $urlBuilder,
		\Magento\Framework\Locale\ResolverInterface $localeResolver,
		\Magento\Framework\Message\ManagerInterface $messageManager,
		DataConverter $dataConverter,
        array $data = array()
    ) {
        parent::__construct(
            $context,
            $registry,
            $extensionFactory,
            $customAttributeFactory,
            $paymentData,
            $scopeConfig,
            $logger,
            null,
            null,
            $data
        );

        $this->_checkoutSession = $checkoutSession;
        $this->_session = $session;
        $this->customerSession = $customerSession;
        $this->_paymentData = $paymentData;
        $this->_store = $store;
        $this->_objectManager = $objectManager;
        $this->_urlBuilder = $urlBuilder;
		$this->messageManager = $messageManager;
		$this->_localeResolver = $localeResolver;
		$this->dataConverter = $dataConverter;

    }


    /**
     * Availability for currency
     *
     * @param string $currencyCode
     * @return bool
     */
    public function canUseForCurrency($currencyCode)
    {
        if (!in_array($currencyCode, $this->getsupportedCurrencyCodes())) {
            return false;
        }
        return true;
    }

    /**
     * Instantiate state and set it to state object
     *
     * @param string $paymentAction
     * @param DataObject
     */
    public function initialize($paymentAction, $stateObject)
    {
        $stateObject->setState(Order::STATE_PENDING_PAYMENT);
        $stateObject->setStatus('pending_payment');
        $stateObject->setIsNotified(false);

    }

    public function getCurrency()
    {
        return $this->getConfigData('currency');
    }

    public function getShopId()
    {
        return trim($this->getConfigData('sia_shopid'));
    }
	
	public function getKeyStart()
    {
        $keystart = $this->_objectManager->create('Magento\Framework\Encryption\Encryptor')->decrypt(trim($this->getConfigData('sia_keystart')));
		return $keystart;
    }
	
	public function getKeyResult()
    {
        $keyresult = $this->_objectManager->create('Magento\Framework\Encryption\Encryptor')->decrypt(trim($this->getConfigData('sia_keyresult')));
		return $keyresult;
    }
	
	public function getDescription()
    {
		return trim($this->getConfigData('sia_trdesc'));
    } 
	
	public function getShopemail()
    {
		return trim($this->getConfigData('sia_shopemail'));
    }  

    public function getInstallments(){
        return trim($this->getConfigData('Installments'));
    }   

    public function getAllowedCurrency()
    {
        return $this->getConfigData(explode(",", Currency));
    }
	
	public function getsupportedCurrencyCodes()
    {
        return explode(",", $this->getConfigData('allowed_currency'));
    }	

    public function getPaymentMode()
    {
        return $this->getConfigData('sia_mode');
    }
	
	public function getAccountingMode()
    {
        return $this->getConfigData('sia_accounting_mode');
    }  
	
	public function getAuthorMode()
    {
        return $this->getConfigData('sia_author_mode');
    }  
	
	public function getReceipt()
    {
        return $this->getConfigData('sia_receipt');
    }
	
	public function getTds()
    {
        return $this->getConfigData('sia_tds');
    }

    public function getOrderStatus()
    {
        return $this->getConfigData('order_status');
    }
    
	public function getConfirmUrl()
    {
        $confirmurl = $this->_urlBuilder->getUrl('siavposr/attpay/success/', array('_secure' => true));
        return $confirmurl;
    }

    public function getCancelUrl()
    {
        $cancelurl = $this->_urlBuilder->getUrl('siavposr/attpay/fail/', array('_secure' => true));
        return $cancelurl;
    }
	
	public function getCgiUrl()
    {
        if ($this->getConfigData('sia_mode') == 'test'){
		  $action_adr = 'https://virtualpostest.sia.eu/vpos/payments/main';
		} else {
		  $action_adr = 'https://virtualpos.sia.eu/vpos/payments/main';
		}
        return $action_adr;
    }
	
    public function getSession()
    {
        return $this->_session;
    }

    public function getCheckout()
    {
        return $this->_checkoutSession;
    }

    public function getQuote()
    {
        return $this->getCheckout()->getQuote();
    }

    public function getExtraFee(){
        $fee = $this->getConfigData('extra_fee');
        return $fee;
    }

    public function addSiavposFields($form){
      
		$order = $this->_checkoutSession->getLastRealOrder();

        $lastIncrementId = $order->getIncrementId();
        $order_id_long =  $order->getIncrementId();
        $currency_code = $order->getBaseCurrencyCode();
        $locale_code = $this->_localeResolver->getLocale();
		
		$objectManager = \Magento\Framework\App\ObjectManager::getInstance();
		$transaction = $objectManager->create('Webit\Siavpos\Model\Siavpos')->load($order_id_long, 'order_id' )->getData();
		if(!isset($transaction['order_status']) || $transaction['order_status']==''){
		 $atpay_fee = $order->getFeeAmount();
         $order->setGrandTotal($order->getGrandTotal() + $atpay_fee);
         $order->setBaseGrandTotal($order->getBaseGrandTotal() + $atpay_fee)->save();
		}
    
        $currency_symbol='';
        $formlang='';
		
		switch ($currency_code) {
			case 'EUR':
				$currency_symbol = 978;
				break;
			case 'GBP':
				$currency_symbol = 826;
				break;
			case 'BGN':
				$currency_symbol = 975;
				break;
			case 'RON':
				$currency_symbol = 946;
				break;
		   case 'PLN':
				$currency_symbol = 985;
				break;
			default:
				$currency_symbol = 978;
		}
		
		if (preg_match("/gr/i", $locale_code) || preg_match("/el/i", $locale_code)) {
			 $formlang = 'EL';
			} elseif (preg_match("/it/i", $locale_code)) {
			 $formlang = 'IT';
			} elseif (preg_match("/sr/i", $locale_code)) {
			 $formlang = 'SR';
			} elseif (preg_match("/sk/i", $locale_code)) {
			 $formlang = 'SK';
			} else {
			 $formlang = 'EN';
		}

        $amount_new =  preg_replace('/,/', '.', $order->getBaseGrandTotal());
		$charge = number_format((float)$amount_new, 2, '.', '');
		$amountcents = round($charge * 100);
        $time_period = $this->getCCInstallment($lastIncrementId);
		$mref = substr($order_id_long . "-REF".md5(uniqid(rand(), true)), 0, 50);

        if(isset($time_period) && $time_period!="" && $time_period > 1){
            $installments = $time_period;
        } else {
            $installments = '0';
        }
        

		$customer_mail = $order->getCustomerEmail();
		$firstname = $order->getCustomerFirstname();
    	$lastname = $order->getCustomerLastname();
		
		$billing = $order->getBillingAddress();
		if (!empty($billing)) {
            $billing_phone = $billing->getTelephone();
			
			$cphone = preg_replace("/[^0-9]/", "", $billing_phone);
			if(isset($cphone) && $cphone!=''){	
				$payerPhone = $cphone;
					} else {
				$payerPhone = '';
			}
			
            $billCountry = $billing->getCountryId();
			$iso_billing_country = $this->dataConverter->country_code($billCountry);
			
			$billStateId = $billing->getRegionId();
			$_regionFactory = $objectManager->get('Magento\Directory\Model\RegionFactory');
    		$regionModel = $_regionFactory->create();
    		if (is_numeric($billStateId)) {
					$shipperRegion = $_regionFactory->create()->load($billStateId);
					if($shipperRegion->getId()){
						$shipperRegionCode = $shipperRegion->getCode();
						$billState = substr($shipperRegionCode,0,1);
				}
			} else {
			$billState = '';
			}
			
			if(isset($billCountry) && $billCountry=='GR' && isset($shipperRegionCode)){
			$iso_billing_state = $this->dataConverter->state_code($shipperRegionCode);
			} elseif(isset($shipperRegionCode)) {
			$iso_billing_state = substr($shipperRegionCode,0,3);
			} else {
			$iso_billing_state = '';
			}
		
            $billZip = $billing->getPostCode();
            $billCity = $billing->getCity();
            $billAddress = implode(',', $billing->getStreet());
        }
        $shipping = $order->getShippingAddress();
        if (!empty($shipping)) {
            $shipCountry = $shipping->getCountryId();
			$iso_shipping_country = $this->dataConverter->country_code($shipCountry);
			
			$shipStateId = $shipping->getRegionId();
			$_regionFactory = $objectManager->get('Magento\Directory\Model\RegionFactory');
    		$regionModel = $_regionFactory->create();
    		if (is_numeric($shipStateId)) {
					$shipperRegion = $_regionFactory->create()->load($shipStateId);
					if($shipperRegion->getId()){
						$shipperRegionCode = $shipperRegion->getCode();
						$shipState = substr($shipperRegionCode,0,1);
				}
			} else {
			$shipState = '';
			}
			
			if(isset($shipCountry) && $shipCountry=='GR' && isset($shipperRegionCode)){
			$iso_shipping_state = $this->dataConverter->state_code($shipperRegionCode);
			} elseif(isset($shipperRegionCode)) {
			$iso_shipping_state = substr($shipperRegionCode,0,3);
			} else {
			$iso_shipping_state = '';
			}
		
            $shipZip = $shipping->getPostCode();
            $shipCity = $shipping->getCity();
            $shipAddress = implode(',', $shipping->getStreet());
        }
		
		if ($this->getReceipt()=='Y'){
			  $sia_options = 'BPRV';
			} else {
			  $sia_options = 'BGPRV';
			}
			
		if(isset($installments) && $installments > 1){
		$installments_number = '&INSTALLMENTSNUMBER='.$installments;
		} else {
		$installments_number = '';
		}	
		
		if($this->getTds()=='Y'){
			$json_array = array(
			"billAddrCity" => $this->dataConverter->maxlength($this->dataConverter->clean_string($billCity),50),
			"billAddrCountry" => $iso_billing_country,
			"billAddrLine1" => $this->dataConverter->maxlength($this->dataConverter->clean_string($billAddress),50),
			"billAddrPostCode" => $this->dataConverter->maxlength($billZip,16),
			"billAddrState" => $this->dataConverter->maxlength($iso_billing_state,3),
			"homePhone" => $this->dataConverter->phone_format($payerPhone,$iso_billing_country),
			"mobilePhone" => $this->dataConverter->phone_format($payerPhone,$iso_billing_country),
			"shipAddrCity" => $this->dataConverter->maxlength($this->dataConverter->clean_string($shipCity),50),
			"shipAddrCountry" => $iso_shipping_country,
			"shipAddrLine1" => $this->dataConverter->maxlength($this->dataConverter->clean_string($shipAddress),50),
			"shipAddrPostCode" => $this->dataConverter->maxlength($shipZip,16),
			"shipAddrState" => $this->dataConverter->maxlength($iso_shipping_state,3),
			"workPhone" => $this->dataConverter->phone_format($payerPhone,$iso_billing_country),
			"deliveryEmailAddress" => $this->dataConverter->maxlength($customer_mail,254));
	
			$json_string = $this->dataConverter->to_json($json_array);
			$initVector = null;
			$aesSecret = substr($this->getKeyResult(), 0, 16);
			$raw_tds = @openssl_encrypt(
				$json_string,
				'AES-128-CBC',
				$aesSecret,
				OPENSSL_RAW_DATA,
				$initVector
			);
			
			$tds = base64_encode($raw_tds);
			
			$mac = strtoupper(hash_hmac('sha256','URLMS='.$this->getConfirmUrl().'&URLDONE='.$this->getConfirmUrl().'&ORDERID='.$mref.'&SHOPID='.$this->getShopId().'&AMOUNT='.$amountcents.'&CURRENCY='.$currency_symbol.'&ACCOUNTINGMODE='.$this->getAccountingMode().'&AUTHORMODE='.$this->getAuthorMode().'&OPTIONS='.$sia_options.'&NAME='.$this->dataConverter->maxlength($firstname,45).'&SURNAME='.$this->dataConverter->maxlength($lastname,45).'&ORDDESCR='.$this->dataConverter->maxlength($this->getDescription(),140).'&3DSDATA='.$tds.$installments_number,$this->getKeyStart(),false));
			} else {
			$mac = strtoupper(hash_hmac('sha256','URLMS='.$this->getConfirmUrl().'&URLDONE='.$this->getConfirmUrl().'&ORDERID='.$mref.'&SHOPID='.$this->getShopId().'&AMOUNT='.$amountcents.'&CURRENCY='.$currency_symbol.'&ACCOUNTINGMODE='.$this->getAccountingMode().'&AUTHORMODE='.$this->getAuthorMode().'&OPTIONS='.$sia_options.'&NAME='.$this->dataConverter->maxlength($firstname,45).'&SURNAME='.$this->dataConverter->maxlength($lastname,45).'&ORDDESCR='.$this->dataConverter->maxlength($this->getDescription(),140).$installments_number,$this->getKeyStart(),false));
		}
		
		 $transactionData = ['order_id'=> $order_id_long, 'oid'=> $order_id_long, 'mref'=> $mref, 'cc_installments'=> $installments, 'order_status'=> "I", 'currency'=> $currency_symbol, 'amount'=> $charge, 'created_at'=>date('Y-m-d h:i:s', time()), 'updated_at'=>date('Y-m-d h:i:s', time())];
		$save_transaction = $this->_objectManager->create('Webit\Siavpos\Model\Siavpos');
        $save_transaction->addData($transactionData)->save();
		
        $form->addField("PAGE", 'hidden', array('name' => 'PAGE', 'value' => 'LAND'));
        $form->addField("AMOUNT", 'hidden', array('name' => 'AMOUNT', 'value' => $amountcents));
        $form->addField("CURRENCY", 'hidden', array('name' => 'CURRENCY', 'value' => $currency_symbol));
        $form->addField("ORDERID", 'hidden', array('name' => 'ORDERID', 'value' => $mref));
        $form->addField("SHOPID", 'hidden', array('name' => 'SHOPID', 'value' => $this->getShopId()));
        $form->addField("URLBACK", 'hidden', array('name' => 'URLBACK', 'value' => $this->getCancelUrl().'?ORDERID='.$mref));
        $form->addField("URLDONE", 'hidden', array('name' => 'URLDONE', 'value' => $this->getConfirmUrl()));
        $form->addField("URLMS", 'hidden', array('name' => 'URLMS', 'value' => $this->getConfirmUrl()));
        $form->addField("ACCOUNTINGMODE", 'hidden', array('name' => 'ACCOUNTINGMODE', 'value' => $this->getAccountingMode()));
        $form->addField("AUTHORMODE", 'hidden', array('name' => 'AUTHORMODE', 'value' => $this->getAuthorMode()));
        $form->addField("MAC", 'hidden', array('name' => 'MAC', 'value' => $mac));
        $form->addField("LANG", 'hidden', array('name' => 'LANG', 'value' => $formlang));
        $form->addField("SHOPEMAIL", 'hidden', array('name' => 'SHOPEMAIL', 'value' => $this->dataConverter->maxlength($this->getShopemail(),50)));
        $form->addField("OPTIONS", 'hidden', array('name' => 'OPTIONS', 'value' => $sia_options));
        $form->addField("EMAIL", 'hidden', array('name' => 'EMAIL', 'value' => $this->dataConverter->maxlength($customer_mail,50)));
        $form->addField("ORDDESCR", 'hidden', array('name' => 'ORDDESCR', 'value' => $this->dataConverter->maxlength($this->getDescription(),140)));
        $form->addField("NAME", 'hidden', array('name' => 'NAME', 'value' => $this->dataConverter->maxlength($firstname,45)));
        $form->addField("SURNAME", 'hidden', array('name' => 'SURNAME', 'value' => $this->dataConverter->maxlength($lastname,45)));
		if(isset($installments) && $installments > 1){
		$form->addField("INSTALLMENTSNUMBER", 'hidden', array('name' => 'INSTALLMENTSNUMBER', 'value' => $installments));
		}
		
		if($this->getTds()=='Y'){
		$form->addField("3DSDATA", 'hidden', array('name' => '3DSDATA', 'value' => $tds));
		}
        
        return $form;
    }


    public function validate()
    {
        parent::validate();
        $currency_code = $this->getQuote()->getBaseCurrencyCode();
        if (isset($currency_code) && $currency_code!='' && !in_array($currency_code, $this->getsupportedCurrencyCodes())) {
            throw new \Magento\Framework\Exception\LocalizedException(
                __('Selected currency code ('.$currency_code.') is not compatible.')
            );
        }
        
        return $this;
    }

    public function canCapture()
    {
 
        return true;
    }

    public function getOrderPlaceRedirectUrl()
    {

          return $this->getUrl('siavposr/attpay/redirect', array('_secure' => true));
    }
    
    public function isAvailable(\Magento\Quote\Api\Data\CartInterface $quote = null)
    {
    
        if( $this->getConfigData('active') == 1){
            return true;
        }
        // Default, restrict access
        return false;
    }

    /**
     * Get instructions text from config
     *
     * @return string
     */
    public function getInstructions()
    {
        return trim($this->getConfigData('instructions'));
    }


    /**
     * Add the checkout-form-data to the checkout session
     *
     * @param  DataObject $data
     * @return $this
     */
    public function assignData(DataObject $data)
    {
        parent::assignData($data);
        $oInfoInstance = $this->getInfoInstance();
        $oInfoInstance->setAdditionalInformation('cc_installments', $this->getAdditionalDataEntry($data, 'cc_installments'));

        return $this;
    }

    /**
     * Return data from data-object
     * Needed because of different ways to read from it for different magento versions
     *
     * @param  DataObject $oData
     * @param  string     $sKey
     * @return string|null
     */
    public function getAdditionalDataEntry(DataObject $oData, $sKey)
    {
        // The way to read the form-parameters changed with version 2.0.6
        if (version_compare($this->getMagentoVersion(), '2.0.6', '>=')) { // Magento 2.0.6 and above
            $aAdditionalData = $oData->getAdditionalData();
            if (isset($aAdditionalData[$sKey])) {
                return $aAdditionalData[$sKey];
            }
            return null;
        }
        // everything below 2.0.6
        return $oData->getData($sKey);
    }

    /**
     * Returns the shop-version of the Magento 2 shop
     *
     * @return string
     */
    public function getMagentoVersion()
    {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $magentoversion = $objectManager->create('\Magento\Framework\App\ProductMetadata');
        return $magentoversion->getVersion();
    }


    public function getCCInstallment($lastIncrementId){
        $order = $this->_objectManager->create('Magento\Sales\Model\Order');
        $order->loadByIncrementId($lastIncrementId);
        $instalments_period = $order->getPayment()->getAdditionalInformation('cc_installments');
        return $instalments_period;
          
    }

    /**
     * Retrieve block type for method form generation
     *
     * @return string
     */
    public function getInfoBlockType()
    {
        return $this->_infoBlockType;
    }

    public function getOrderTotal(){
        $lastIncrementId = $this->_checkoutSession->getLastRealOrder()->getBaseGrandTotal();
        return $lastIncrementId;
    }
}