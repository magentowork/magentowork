<?php

namespace Webit\Siavpos\Model\ResourceModel;

class Siavpos extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    public function _construct()
    {
        $this->_init('siavpos_transactions', 'id');
    }
}