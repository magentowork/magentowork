<?php

namespace Webit\Siavpos\Model\ResourceModel\Siavpos;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
   
    public function _construct()
    {
        $this->_init('Webit\Siavpos\Model\Siavpos', 'Webit\Siavpos\Model\ResourceModel\Siavpos');
    }
}