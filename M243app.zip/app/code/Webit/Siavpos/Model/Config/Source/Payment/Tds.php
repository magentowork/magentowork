<?php

namespace Webit\Siavpos\Model\Config\Source\Payment;

class Tds implements \Magento\Framework\Option\ArrayInterface
{
	// Load payment modes
	protected $payments = array( 
		'Y' 				=> 'Yes (recommended)',
		'N' 				=> 'No',
	);

	/**
	 * Options getter
	 *
	 * @return array
	 */
	public function toOptionArray()
	{
		$payments_array = array();
		foreach ($this->payments as $key => $value ) {
			$payments_array[] = array( 'value' => $key, 'label' => $value );
		}
		
		return $payments_array;
	}

	/**
     * Get options in "key-value" format
     *
     * @return array
     */
    public function toArray()
    {
    	$payments_array = array();
    	foreach ($this->payments as $key => $value ) {
			$payments_array[$key] = $value ;
		}
		return $payments_array;
    }	
}