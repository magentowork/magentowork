<?php

namespace Webit\Siavpos\Model;

class Siavpos extends \Magento\Framework\Model\AbstractModel
{   

    public function _construct()
    {
        $this->_init('Webit\Siavpos\Model\ResourceModel\Siavpos');
    }
}