<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Webit\Siavpos\Block\Info;

class Instructions extends \Magento\Payment\Block\Info
{
    /**
     * @var string
     */
    //protected $_template = 'Webit_Siavpos::info/siavpos.phtml';
    protected $_instructions;
    protected $_ccinstallments;

    /**
     * @return string
     */
    public function toPdf()
    {
        $this->setTemplate('Webit_Siavpos::info/pdf/siavpos.phtml');
        return $this->toHtml();
    }

        /**
     * Get instructions text from order payment
     * (or from config, if instructions are missed in payment)
     *
     * @return string
     */
    public function getInstructions()
    {
        if ($this->_instructions === null) {
            $this->_instructions = $this->getInfo()->getAdditionalInformation(
                'instructions'
            ) ?: trim($this->getMethod()->getConfigData('instructions'));
        }
        return $this->_instructions;
    }

    public function getCcInstallments(){
        if ($this->_ccinstallments === null) {
            $this->_ccinstallments = $this->getInfo()->getAdditionalInformation(
                'cc_installments'
            ) ?: trim($this->getMethod()->getConfigData('cc_installments'));
        }
        return $this->_ccinstallments;
    }

}