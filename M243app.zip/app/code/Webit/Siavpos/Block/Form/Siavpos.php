<?php
/**
 * Copyright © 2016 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace Webit\Siavpos\Block\Form;

use Magento\Payment\Model\MethodInterface;

/**
 * Payment method form base block
 */
class Siavpos extends \Webit\Siavpos\Block\Form\AbstractInstruction
{
    /**
     * @var string
     */
    //protected $_template = 'Webit_Siavpos::form/cc.phtml';
     protected $_template = 'form/siavpos.phtml';

    /**
     * Payment config model
     *
     * @var \Magento\Payment\Model\Config
     */
    protected $_paymentConfig;

    /**
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param \Magento\Payment\Model\Config $paymentConfig
     * @param array $data
     */

    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        \Magento\Payment\Model\Config $paymentConfig,
        array $data = []
    ) {
       
        parent::__construct($context, $data);
        $this->_paymentConfig = $paymentConfig;
    }

    public function getQuote()
    {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        return $objectManager->get('\Magento\Checkout\Model\Session')->getQuote();
    }
    
        
    public function displayInstallments()
    {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $scopeConfig = $objectManager->create('\Magento\Framework\App\Config\ScopeConfigInterface');
        $instal_logic = $scopeConfig->getValue('payment/attpay/Installments');
 
        if(isset($instal_logic) && $instal_logic!=''){
        
            $instal_eurobank = array();
            $split_instal_eurobank = explode(',', $instal_logic);
            $qtotal = $this->getQuote()->getGrandTotal();
            $c = count ($split_instal_eurobank);
            $instal_eurobank['0'] = ''.__('No installments');

            for($i=0; $i<$c; $i++)
            {
                list($instal_amount, $instal_term) = explode(":", $split_instal_eurobank[$i]);
            
                if($qtotal >= $instal_amount){
                    $period_amount = round(($qtotal / $instal_term), 2);
                    $period_amount = number_format($period_amount, 2, '.', '');
                    $instal_eurobank[$instal_term] = $instal_term . __(' installments').'( ' . $instal_term . ' x '. $period_amount . ')' ;
                }
            }

            return $instal_eurobank;
        }
    }

     /**
     * Render block HTML
     *
     * @return string
     */
    protected function _toHtml()
    {
        $this->_eventManager->dispatch('siavposr_form_block_to_html_before', ['block' => $this]);
        return parent::_toHtml();
    }
}
