<?php
namespace Webit\Siavpos\Block\Adminhtml\Sales\Order\Invoice;
class Totals extends \Magento\Framework\View\Element\Template
{
    public function getInvoice()
    {
        return $this->getParentBlock()->getInvoice();
    }
    /**
     * Get data (totals) source model
     *
     * @return \Magento\Framework\DataObject
     */
    public function getSource()
    {
        return $this->getParentBlock()->getSource();
    }
    
    /**
     * Initialize payment fee totals
     *
     * @return $this
     */
    public function initTotals()
    {

        $this->getParentBlock();
        $this->getInvoice();
        $this->getSource();
        
        if(!$this->getSource()->getId()) {
            return $this;
        }
        $fee = new \Magento\Framework\DataObject(
            [
                'code' => 'fee',
                'strong' => false,
                'value' => $this->getSource()->getFeeAmount(),
                'label' => __('Payment Fee Amount'),
            ]
        );
        $this->getParentBlock()->addTotalBefore($fee, 'grand_total');
        return $this;
    }
}