<script>
    require([
        'jquery'
    ], function ($, script) {
        //Your code here
        //alert('Here');
    });
    // ]]>
</script>