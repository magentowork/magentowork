define([
    'jquery',
    'mage/translate',
    'jquery/ui',
    'Magento_Catalog/js/product/view/product-ids-resolver',
], function ($, $t,alert, idsResolver) {
    'use strict';

    return function (widget) {
      console.log('catalog-add-to-cart-mixin');

    $.widget('mage.catalogAddToCart', widget, {

        /**
         * @param {jQuery} form
         */
        ajaxSubmit: function (form) {
            var self = this,
                productIds = idsResolver(form),
                formData;

            $(self.options.minicartSelector).trigger('contentLoading');
            self.disableAddToCartButton(form);
            formData = new FormData(form[0]);

            $.ajax({
                url: form.attr('action'),
                data: formData,
                type: 'post',
                dataType: 'json',
                cache: false,
                contentType: false,
                processData: false,

                /** @inheritdoc */
                beforeSend: function () {
                    if (self.isLoaderEnabled()) {
                        $('body').trigger(self.options.processStart);
                    }
                    /*To hide loader on mini-cart*/
                    $(".loading-mask").show();
                    /*****************************/
                },

                /** @inheritdoc */
                success: function (res) {

                    var eventData, parameters;
                   
                    $(document).trigger('ajax:addToCart', {
                        'sku': form.data().productSku,
                        'productIds': productIds,
                        'form': form,
                        'response': res
                    });

                    if (self.isLoaderEnabled()) {
                        $('body').trigger(self.options.processStop);
                    } 
                    if (res.backUrl) {
                        eventData = {
                            'form': form,
                            'redirectParameters': []
                        };
                        // trigger global event, so other modules will be able add parameters to redirect url
                        $('body').trigger('catalogCategoryAddToCartRedirect', eventData);

                        if (eventData.redirectParameters.length > 0 &&
                            window.location.href.split(/[?#]/)[0] === res.backUrl
                        ) {
                            parameters = res.backUrl.split('#');
                            parameters.push(eventData.redirectParameters.join('&'));
                            res.backUrl = parameters.join('#');
                        }  

                        self._redirect(res.backUrl);   

                        return;
                    }

                    if (res.messages) {
                        $(self.options.messagesSelector).html(res.messages);
                    } 

                    if (res.minicart) {
                        $(self.options.minicartSelector).replaceWith(res.minicart);
                        $(self.options.minicartSelector).trigger('contentUpdated');
                    } 

                    if (res.product && res.product.statusText) {
                        $(self.options.productStatusSelector)
                            .removeClass('available')
                            .addClass('unavailable')
                            .find('span')
                            .html(res.product.statusText);
                    } 
                    if($(".duplicate-create-form").length>=0){ 
                        $(".duplicate-create-form").remove();
                    } 
                    var duplicate = '<iframe class="duplicate-create-form"></iframe>'
                    $("body").append(duplicate);
                    $(".duplicate-create-form").attr('src', BASE_URL);
                    console.log($(".duplicate-create-form"));
                    var counter = 0;
                    var setint = setInterval(function() {
                        counter++;
                        //var qty = jQuery(".duplicate-create-form [data-block='minicart'] .showcart.minicart-icon .cart-qty").html();  
                        if(jQuery(".duplicate-create-form").contents().find("[data-block='minicart'] .block.block-minicart")
                        && jQuery(".duplicate-create-form").contents().find("[data-block='minicart'] .block.block-minicart")[0]
                        && jQuery(".duplicate-create-form").contents().find("[data-block='minicart'] .block.block-minicart")[0].innerHTML){
                           // console.log(jQuery(".duplicate-create-form [data-block='minicart'] .block.block-minicart"));
                            clearInterval(setint); 
                        var htm = jQuery(".duplicate-create-form").contents().find("[data-block='minicart'] .block.block-minicart")[0].innerHTML;
                        setTimeout(function(){
                            $(".duplicate-create-form").remove();
                        },0)
                        $(".page-wrapper [data-block='minicart'] .block.block-minicart").html(htm);
                        }
                        if(counter>100) {
                            clearInterval(setint);
                        } 
                    },500); 
                        /*To hide loader on mini-cart*/
                        setTimeout(function() {
                            $(".loading-mask").hide();
                                if ($("#qty").length > 0) {
                                    var currentQty = $(".counter-number").text();
                                    var newQty = $('#qty').val();
                                    var finalQty = parseInt(currentQty) + parseInt(newQty);
                                    $('.counter-number').text(finalQty);
                                }
                                else{
                                    var currentQty = $(".counter-number").text();
                                    var newQty = 1;
                                    var finalQty = parseInt(currentQty) + parseInt(newQty);
                                    $('.counter-number').text(finalQty);
                                }
                    }, 3000);
                    /*******************************/
                    self.enableAddToCartButton(form);
                }, 
 
                /** @inheritdoc */ 
                error: function (res) {
                    $(document).trigger('ajax:addToCart:error', {
                        'sku': form.data().productSku,
                        'productIds': productIds,
                        'form': form,
                        'response': res
                    });
                },

                /** @inheritdoc */
                complete: function (res) {
                    if (res.state() === 'rejected') {
                        location.reload();
                    }
                }
            });
        }

    });

    return $.mage.catalogAddToCart;
  }
});