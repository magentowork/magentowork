define(['jquery'], function($){
    "use strict";
    return function customcollapse() {

        var setint = setInterval(function(){
                console.log($(".login-popup") && $(".login-popup").length);
                if($(".login-popup") && $(".login-popup").length) {
                     $(document).on("click",".login-popup", function(){  

                            if( $('#social-login-popup').parents('aside')){
                                $('#social-login-popup').parents('aside').addClass('_show');
                                $('#social-login-popup').parents('aside').css('z-index','2');
                                $('#social-login-popup').parents('aside').after('<div class="modals-overlay" style="z-index: 1;"></div>');
                            }
                            console.log($('#social-login-popup')); 
                             $('#social-login-popup').modal({
                                                    title:$('.create-account-title').text(),
                                                    responsive: true,
                                                    autoOpen: true,
                                                    buttons: [],
                                                    opened : function () {
                                                        $(this).removeClass('mfp-hide');
                                                        $('.social-login.authentication').show();
                                                        $('.social-login.create').hide();
                                                    }
                                                });
                                });
                     $(document).on("click",".action-close", function(){  
                        $('.modals-overlay').remove();
                     });

                    clearInterval(setint);
                }

                var secint = setInterval(function(){
        if($('input[name*="create_account_checkbox"]').length){
 
              $('div[name*="billingAddress.create_account_password"]').css('display','none');
              $('div[name*="billingAddress.create_account_password"]').css('display','none');
            $('input[name*="create_account_checkbox"]').change(function() { 
                if($('input[name*="create_account_checkbox"]:checked').length){ 
                    $('div[name*="billingAddress.create_account_password"]').css('display','block'); 
                    $('div[name*="billingAddress.create_account_password"]').css('display','block');

                    $('div[name*="billingAddress.create_account_password"]').attr('aria-required', true);
                    $('div[name*="billingAddress.create_account_password_confirm"]').attr('aria-required', true); 
                 }
                 else{ 
                    $('div[name*="billingAddress.create_account_password"]').css('display','none'); $('div[name*="billingAddress.create_account_password"]').css('display','none');

                    $('div[name*="billingAddress.create_account_password"]').attr('aria-required', false);

                    $('div[name*="billingAddress.create_account_password_confirm"]').attr('aria-required', false); 
                 }
             });

            clearInterval(secint);
        }

         },1000);

                var issue = setInterval(function(){

                     if($('input[name*="issue_invoice"]').length){ 

                     	       $('div[name*="billingAddress.compny_name"]').css('display','none'); 
                                $('div[name*="billingAddress.profession"]').css('display','none'); 
                                $('div[name*="billingAddress.comp_telephone"]').css('display','none'); 
                                $('div[name*="billingAddress.comp_address"]').css('display','none'); 
                                $('div[name*="billingAddress.vat_no"]').css('display','none'); 
                                $('div[name*="billingAddress.comp_postcode"]').css('display','none'); 
                                $('div[name*="billingAddress.comp_city"]').css('display','none'); 

                         $('input[name*="issue_invoice"]').change(function() { 
                            if($('input[name*="issue_invoice"]:checked').length){  
                                $('div[name*="billingAddress.compny_name"]').css('display','block'); 
                                $('div[name*="billingAddress.profession"]').css('display','block'); 
                                $('div[name*="billingAddress.comp_telephone"]').css('display','block'); 
                                $('div[name*="billingAddress.comp_address"]').css('display','block'); 
                                $('div[name*="billingAddress.vat_no"]').css('display','block'); 
                                $('div[name*="billingAddress.comp_postcode"]').css('display','block'); 
                                $('div[name*="billingAddress.comp_city"]').css('display','block'); 


                                $('div[name*="billingAddress.compny_name"]').attr('aria-required', true);
                                $('div[name*="billingAddress.profession"]').attr('aria-required', true);
                                $('div[name*="billingAddress.comp_telephone"]').attr('aria-required', true);
                                $('div[name*="billingAddress.comp_address"]').attr('aria-required', true);
                                $('div[name*="billingAddress.vat_no"]').attr('aria-required', true); 
                                $('div[name*="billingAddress.comp_postcode"]').attr('aria-required', true); 
                                $('div[name*="billingAddress.comp_city"]').attr('aria-required', true);

                               
                             }
                             else{  
                                $('div[name*="billingAddress.compny_name"]').css('display','none'); 
                                $('div[name*="billingAddress.profession"]').css('display','none'); 
                                $('div[name*="billingAddress.comp_telephone"]').css('display','none'); 
                                $('div[name*="billingAddress.comp_address"]').css('display','none'); 
                                $('div[name*="billingAddress.vat_no"]').css('display','none'); 
                                $('div[name*="billingAddress.comp_postcode"]').css('display','none'); 
                                $('div[name*="billingAddress.comp_city"]').css('display','none'); 


                                $('div[name*="billingAddress.compny_name"]').attr('aria-required', false);
                                $('div[name*="billingAddress.profession"]').attr('aria-required', false);
                                $('div[name*="billingAddress.comp_telephone"]').attr('aria-required', false);
                                $('div[name*="billingAddress.comp_address"]').attr('aria-required', false);
                                $('div[name*="billingAddress.vat_no"]').attr('aria-required', false); 
                                $('div[name*="billingAddress.comp_postcode"]').attr('aria-required', false); 
                                $('div[name*="billingAddress.comp_city"]').attr('aria-required', false);
                             }
                         }); 
                          clearInterval(issue);
                     } 

                },1000); 

            },1000);
        
      
      var setintforpayment = setInterval(function(){


                console.log($('.checkout-payment-method').length);

                if($('.checkout-payment-method').length){
 
                  var paymentdata = $('.checkout-payment-method');
                  $('.checkout-payment-method').remove(); 
                  $('.opc-block-summary').append(paymentdata);

                  var setintforsumm = setInterval(function(){

                        if($('.block.items-in-cart').length){ 
                          

                          var title = $('.opc-block-summary .title.summary'); 
                          var summarry = $('.block.items-in-cart');   
                          var opccomment = $('.opc-payment-additional.comment');  
                          $('.opc > li.checkout-shipping-method').append(title);
                          $('.opc > li.checkout-shipping-method').append(summarry);  
                          $('.opc > li.checkout-shipping-method').append(opccomment); 
                           

                         clearInterval(setintforsumm); 
                        }

                     },1000);

                  clearInterval(setintforpayment); 
                }  

          },1000); 


  var setintforwrap = setInterval(function(){
                  console.log($('.checkout-container').length);
                  if($('.checkout-container').length){ 
                  	if($(".opc-wrapper").length && $("#opc-sidebar").length){ 
                  		 $( ".opc-wrapper,#opc-sidebar" ).wrapAll( "<div class='opc-wrap-div' />");            
                  		 $('.back-to-cart').appendTo('#opc-sidebar');
                  			clearInterval(setintforwrap); 
                  	} 
                }  

          },1000); 
 




    }
});