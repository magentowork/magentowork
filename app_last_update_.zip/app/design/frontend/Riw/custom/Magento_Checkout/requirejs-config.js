var config = {
    config: {
        mixins: {
            'Magento_Catalog/js/catalog-add-to-cart': {
                'Magento_Checkout/js/catalog-add-to-cart-mixin': true
            },
            'Magento_Ui/js/lib/validation/validator': {
                'Magento_Checkout/js/validation-mixin': true
            }
        }
    },
     map: {
        '*': {
           customcheckoutjs: 'Magento_Checkout/js/customcheckout'
        }
    }
};