var config = {
   map: {
    '*': {
        custom:'js/custom'
    }
  }
};