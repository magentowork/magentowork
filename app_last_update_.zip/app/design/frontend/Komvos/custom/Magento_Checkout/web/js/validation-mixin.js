define([
    'jquery',
    'Magento_Ui/js/lib/validation/utils'
], function ($, utils) {
    "use strict";

    return function (validator) {
        console.log('customvalidation+99999999999999999999999'); 

        
        var setint = setInterval(function(){

            if($("#billing-new-address-form") && $("#billing-new-address-form").length) { 

        validator.addRule(
        'required-entry-if-create-account-checked',
        function (value) { 
            if(!$('input[name*="create_account_checkbox"]').is(":checked")) {
                    return true;
                } else {
                    return !utils.isEmpty(value);
                }
        },
        $.mage.__('This is a required field.')
        );
        validator.addRule(
            'validate-create_password',
            function (value) {
               // console.log('run validation----------------');
                if(!$('input[name*="create_account_checkbox"]').is(":checked")) { 
                    return true;
                } else {
                    var pass; 
                    if (value == null) {
                        return false;
                    }

                    pass = $.trim(value);
 

                    if (!pass.length) {
                        return true;
                    }

                    return !(pass.length > 0 && pass.length < 6);
                }
            },
            $.mage.__('Please enter 6 or more characters. Leading and trailing spaces will be ignored......')
        );
        validator.addRule(
            'validate-confirm_password',
            function (value) { 
                //console.log('confirm pass validation----------------');
                    //console.log($('input[name*="create_account_checkbox"]').is(":checked"));

                if(!$('input[name*="create_account_checkbox"]').is(":checked")) {
                    return true;
                } else {
                    return $('input[name*="create_account_password"]').val() === $('input[name*="create_account_password_confirm"]').val();
                }
            },
            $.mage.__('Please enter the same value again.')
        );


                clearInterval(setint);

            }
     

          },1000);

       
return validator;
}

});