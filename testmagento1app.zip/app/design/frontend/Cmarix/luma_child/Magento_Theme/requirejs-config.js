var config = {
    paths: {
        owlcarousel: "Magento_Theme/js/common"
    },
    shim: {
        owlcarousel: {
            deps: ['jquery']
        }
    }
};