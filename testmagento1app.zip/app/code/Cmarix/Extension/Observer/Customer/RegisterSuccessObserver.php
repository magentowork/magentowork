<?php
namespace Cmarix\Extension\Observer\Customer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Store\Model\ScopeInterface;


class RegisterSuccessObserver implements ObserverInterface
{
    protected $customer;
    protected $group;
    protected $_customerRepositoryInterface;
    protected $scopeConfig;

    public function __construct(
        \Magento\Customer\Model\Customer $customer,
        \Magento\Customer\Model\Group $group,
        \Magento\Customer\Api\CustomerRepositoryInterface $customerRepositoryInterface,
        ScopeConfigInterface $scopeConfig
        
    ) {
        $this->customer = $customer;
        $this->group = $group;
        $this->_customerRepositoryInterface = $customerRepositoryInterface;
        $this->scopeConfig = $scopeConfig;

       }

    public function execute(\Magento\Framework\Event\Observer $observer){
        $customerEmail = $observer->getEvent()->getCustomer()->getEmail();
        $event = $observer->getEvent();
        $customer = $event->getCustomer();

        list($user, $domain) = explode('@',$customerEmail);

        $empId = $this->scopeConfig->getValue("extension/group_list/list",ScopeInterface::SCOPE_STORE);
        $empemail = $this->scopeConfig->getValue("extension/group_list/cc",ScopeInterface::SCOPE_STORE);

        $data = explode(",",$empemail);    

        // $cusGrpCode = 'Employee';
        // $existingGroup =  $this->group->load($cusGrpCode, 'customer_group_code');
        // $empId = $existingGroup->getData('customer_group_id');

        if (in_array($domain,$data)){
            if($empId != ""){
                $customer->setGroupId($empId);
                $this->_customerRepositoryInterface->save($customer);
                
            }
        }
        return $this;
    }  
}