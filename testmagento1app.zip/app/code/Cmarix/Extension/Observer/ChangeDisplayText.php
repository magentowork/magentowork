<?php

namespace Cmarix\Extension\Observer;

class ChangeDisplayText implements \Magento\Framework\Event\ObserverInterface
{
	public function execute(\Magento\Framework\Event\Observer $observer)
	{
		$displayText = $observer->getEvent()->getMpText();
        $recordId = $displayText->getRecordId(); 
        $name = $displayText->getName();

        echo 'Record Id:'.$recordId .'</br></br>'.'Record Name:'. $name;
		return $this;
	}
}   