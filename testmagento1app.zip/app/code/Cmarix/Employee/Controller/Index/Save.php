<?php 
namespace Cmarix\Employee\Controller\Index;
 
use Magento\Framework\App\Filesystem\DirectoryList;
 
class Save extends \Magento\Framework\App\Action\Action
{
     protected $_pageFactory;
     protected $_postFactory;
     protected $_filesystem;
 
     public function __construct(
          \Magento\Framework\App\Action\Context $context,
          \Magento\Framework\View\Result\PageFactory $pageFactory,
          \Cmarix\Employee\Model\EmployeeFactory $postFactory,
          \Magento\Framework\Filesystem $filesystem
          )
     {
          $this->_pageFactory = $pageFactory;
          $this->_postFactory = $postFactory;
          $this->_filesystem = $filesystem;
          return parent::__construct($context);
     }
 
     public function execute()
     {
              $input = $this->getRequest()->getPostValue();
               $email = $this->getRequest()->getpostValue('email');
               $post = $this->_postFactory->create();

               $collection = $post->getCollection();
               $hello = $collection->addFieldToFilter('email',['eq' => $email]);

               if($hello == '')
               {
                    $post->setData($input)->save();
                    $this->messageManager->addSuccess(
                         __('data inserted successfully')
                     );
               return $this->_redirect('employee/index/index');
         

               }
               else{
                    $this->messageManager->addError(
                         __('We can\'t process your request right now.email already exists')
                    );
                    return $this->_redirect('employee/index/index');
                    

               }


        
       
          
     }  
}
?>