<?php

namespace Cmarix\Employee\Cron;


class Demo  extends \Magento\Framework\App\Action\Action
{

    protected $_fileCsv;
    protected $_productloader; 
    protected $productRepository;
  
public function __construct(
   \Magento\Backend\App\Action\Context $context,
   \Magento\Catalog\Model\Product $_productloader,
   \Magento\Framework\Module\Dir\Reader $moduleReader,
   \Magento\Catalog\Api\ProductRepositoryInterface $productRepository,
    \Magento\Framework\File\Csv $fileCsv
) {
    $this->_moduleReader = $moduleReader;
    $this->_productloader = $_productloader;
    $this->_fileCsv = $fileCsv;
    $this->productRepository = $productRepository;
        
   
}

public function execute()

{
   
$directory = $this->_moduleReader->getModuleDir('etc', 'Cmarix_Employee'); 
 //$product = $this->_productloader->create();
 

 $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/import-new.log');
 $logger = new \Zend\Log\Logger();
 $logger->addWriter($writer);

$file = $directory . '/weekday.csv';
if (file_exists($file))
    {
    $csvData = $this->_fileCsv->getData($file);

 //  This skips the first line of your csv file, since it will probably be a heading. Set $i = 0 to not skip the first line. 
    // for($i=1; $i<count($data); $i++) {
    //    var_dump($data[1]); // $data[$i] is an array with your csv columns as values.
// }
        // print_r(count($csvData));
        // die;
    foreach ($csvData as $row => $data) 
        {
            
        if($row > 0)
            { 
                $sku = $data[2];
                $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
               // $oldproduct = $objectManager->get('Magento\Catalog\Model\Product')->load($sku);
                if($this->_productloader->getIdBySku($sku))

                {
                    $oldproduct = $this->_productloader->load($sku);  
                    $oldproduct->setTypeId('simple') 
                    ->setStatus(1) 
                    ->setAttributeSetId(4)
                    ->setSku($data[2])
                    ->setName($data[1])
                    ->setTaxClassId(0)  
                    ->setCategoryIds(array(2, 11)) 
                    ->setWebsiteIds(array(1))
                    ->setStoreId(0) 
                    ->setUrlKey(rand(1,10000))
                    ->setVisibility(4);
                    $oldproduct->save();
                  

                }
            
                else{
                    $objectManager =  \Magento\Framework\App\ObjectManager::getInstance();
                    $product = $objectManager->create('Magento\Catalog\Model\Product');  
                    $product->setTypeId('simple') 
                    ->setStatus(1) 
                    ->setAttributeSetId(4)
                    ->setSku($data[2])
                    ->setName($data[1])
                    ->setTaxClassId(0) 
                    ->setCategoryIds(array(2, 11)) 
                    ->setWebsiteIds(array(1))
                    ->setStoreId(0) 
                    ->setUrlKey(rand(1,10000))
                    ->setVisibility(4);
                    $product->save();
                  

                }
               
               
               
            }
             
             echo "<pre>";
             echo $row;
             print_r($data);
            
        }

        echo "data inserted succesfully";
    }
}

}
