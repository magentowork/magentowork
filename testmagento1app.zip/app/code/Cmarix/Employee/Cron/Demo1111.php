<?php

namespace Cmarix\Employee\Cron;


class Demo1111 {

  
  public function execute() {

    $file = fopen('var/import/SIMPLE-PRODUCT-update1.csv', 'r', '"'); // set path to the CSV file
    if ($file !== false) {
        
    $objectManager =  \Magento\Framework\App\ObjectManager::getInstance();

    // used for updating product stock - and it's important that it's inside the while loop
    $stockRegistry = $objectManager->get('Magento\CatalogInventory\Api\StockRegistryInterface');
    
   
    // add logging capability
    $writer = new \Zend\Log\Writer\Stream(BP . '/var/log/import-new.log');
    $logger = new \Zend\Log\Logger();
    $logger->addWriter($writer);

    
    $header = fgetcsv($file); // get data headers and skip 1st 
    
    
    // enter the min number of data fields you require that the new product will have (only if you want to standardize the import)
    $required_data_fields = 10;

    
    while ( $row = fgetcsv($file, 3000, ",") ) {

        $data_count = count($row);
        if ($data_count < 1) {
            continue;
        }
    
        // used for setting the new product data
        $product = $objectManager->create('Magento\Catalog\Model\Product');  
               
        $data = array();

      
        $data = array_combine($header, $row);
        $sku = $data['Code'];
       
        if ($data_count < $required_data_fields) {
            $logger->info("Skipping product sku " . $sku . ", not all required fields are present to create the product.");
            continue;
        }
        $qty = $data['Quantity Available'];
        $name = $data['Name'];
        $description = $data['Description'];
        $shortDescription = $data['Short Description'];
        $Country = $data['Country of Origin Manufacture'];
        $thickness = $data['Product - Thickness Veneer'];
        $boarders = $data['Boards per pack'];
        $install = $data['Installation options'];
        
        try {
            
            $product->setTypeId('simple') // type of product you're importing
                    ->setStatus(1) // 1 = enabled
                    ->setAttributeSetId(4) // In Magento 2.2 attribute set id 4 is the Default attribute set (this may vary in other versions)
                    ->setName($name)
                    ->setSku($sku)
                    ->setTaxClassId(0) // 0 = None
                    ->setCategoryIds(array(2, 11)) // array of category IDs, 2 = Default Category
                    ->setDescription($description)
                    ->setShortDescription($shortDescription) // you don't need to set it, because Magento does this by default, but you can if you need to
                    ->setCountry($Country)
                    ->setThicknessVeneer($thickness)
                    ->setBoardsPerPack($boarders)
                    ->setInstallationOptions($install)
                    ->setWebsiteIds(array(1)) // Default Website ID
                    ->setStoreId(0) // Default store ID
                    ->setVisibility(4) // 4 = Catalog & Search
                    ->save();
    
        } catch (\Exception $e) {
            $logger->info('Error importing product sku: '.$sku.'. '.$e->getMessage());
            continue;
        }
    
        // try {
        //     $stockItem = $stockRegistry->getStockItemBySku($sku);
    
        //     if ($stockItem->getQty() != $qty) {
        //         $stockItem->setQty($qty);
        //         if ($qty > 0) {
        //             $stockItem->setIsInStock(1);
        //         }
        //         $stockRegistry->updateStockItemBySku($sku, $stockItem);
        //     }
        // } catch (\Exception $e) {
        //     $logger->info('Error importing stock for product sku: '.$sku.'. '.$e->getMessage());
        //     continue;
        // }
        // unset($product);
    }
    fclose($file);


  }

}
}
