<?php

namespace Cmarix\Employee\Cron;

use \Psr\Log\LoggerInterface;
use Magento\Framework\App\Config\ScopeConfigInterface;
use Magento\Store\Model\ScopeInterface;

class Test {

 
  protected $stockRegistry;
  protected $scopeConfig;

  public function __construct(
    \Magento\CatalogInventory\Api\StockRegistryInterface $stockRegistry,
    ScopeConfigInterface $scopeConfig
  
  ) {

   
    $this->stockRegistry = $stockRegistry;
    $this->scopeConfig = $scopeConfig;

  }

  /**

    * Write to system.log

    *

    * @return void

  */

  public function execute() {
      

$objectManager =  \Magento\Framework\App\ObjectManager::getInstance();
$categorysFactory = $objectManager->get('\Magento\Catalog\Model\CategoryFactory');
 
$categoryId = $this->scopeConfig->getValue("emp/list/category",ScopeInterface::SCOPE_STORE); // YOUR CATEGORY ID

$category = $categorysFactory->create()->load($categoryId);
 
$categoryProducts = $category->getProductCollection()
    ->addAttributeToSelect('*');
 
foreach ($categoryProducts as $product) {
    // get Product data
    $data=$product->getData('sku');
    $inqty = $this->scopeConfig->getValue("emp/list/pqty",ScopeInterface::SCOPE_STORE);
    $sku = $data;
    $stockItem = $this->stockRegistry->getStockItemBySku($sku);
    $oriqty = $stockItem->getQty($sku);
    
    if (strpos($inqty, '-') == false)
       {
        $qty = $oriqty + $inqty;
        $stockItem->setQty($qty);
       } 
     else
      {
        $qty = $oriqty - $inqty;
        $stockItem->setQty($qty);
      }
     // $stockItem->setIsInStock((bool)$qty);
     $this->stockRegistry->updateStockItemBySku($sku, $stockItem);
      }

  }

}