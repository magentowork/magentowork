<?php 
namespace Cmarix\Employee\Model;

use Cmarix\Employee\Api\EmployeeRepositoryInterface;
 
 
class EmployeeRepository implements EmployeeRepositoryInterface
{
     protected $_empinterface;
     protected $_empFactory;
     
 
     public function __construct(
          \Cmarix\Employee\Api\Data\EmployeeInterfaceFactory $empFactory,
          \Cmarix\Employee\Api\EmployeeRepositoryInterface $empinterface
          
          )
     {
          $this->_empFactory = $empFactory;
          $this->_empinterface = $empinterface;
     }
 
     public function getEmployeeById()
     {
           
        $empinter = $this->_empFactory->create();
     
        foreach($empinter as $pro){
          echo $pro->getEntityId();
          echo $pro->getName();


        }
        return $this;
      }  
}
?>