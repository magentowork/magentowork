<?php

namespace Cmarix\Employee\Model;

use Cmarix\Employee\Api\Data\EmployeeInterface;

class Employee extends \Magento\Framework\Model\AbstractModel implements EmployeeInterface
{
    /**
     * CMS page cache tag.
     */
    const CACHE_TAG = 'cmarix_employee';

    /**
     * @var string
     */
    protected $_cacheTag = 'cmarix_employee';

    /**
     * Prefix of model events names.
     *
     * @var string
     */
    protected $_eventPrefix = 'cmarix_employee';

    /**
     * Initialize resource model.
     */
    protected function _construct()
    {
        $this->_init('Cmarix\Employee\Model\ResourceModel\Employee');
    }
    /**
     * Get EntityId.
     *
     * @return int
     */
    public function getEntityId()
    {
        return $this->getData(self::ENTITY_ID);
    }

    /**
     * Set EntityId.
     */
    public function setEntityId($entityId)
    {
        return $this->setData(self::ENTITY_ID, $entityId);
    }


    public function getName()
    {
        return $this->getData(self::NAME);
    }

 
    public function setName($name)
    {
        return $this->setData(self::NAME, $name);
    }


    public function getEmail()
    {
        return $this->getData(self::EMAIL);
    }

 
    public function setEmail($email)
    {
        return $this->setData(self::EMAIL, $email);
    }

   

    public function getTelePhone()
    {
        return $this->getData(self::TELEPHONE);
    }

 
    public function setTelePhone($telePhone)
    {
        return $this->setData(self::TELEPHONE, $telePhone);
    }

    public function getState()
    {
        return $this->getData(self::STATE);
    }

 
    public function setState($state)
    {
        return $this->setData(self::STATE, $state);
    }

    public function getCreatedAt()
    {
        return $this->getData(self::CREATED_AT);
    }

   
    public function setCreatedAt($createdAt)
    {
        return $this->setData(self::CREATED_AT, $createdAt);
    }

    public function getUpdatedAt()
    {
        return $this->getData(self::UPDATED_AT);
    }

   
    public function setUpdatedAt($updatedAt)
    {
        return $this->setData(self::UPDATED_AT, $updatedAt);
    }

}