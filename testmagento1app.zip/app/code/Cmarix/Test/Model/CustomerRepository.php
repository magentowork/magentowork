<?php
namespace Cmarix\Test\Model;

use Cmarix\Test\Api\CustomerRepositoryInterface;
use Cmarix\Test\Api\Data\CustomerInterfaceFactory;
use Magento\Framework\Exception\NoSuchEntityException;

class CustomerRepository implements CustomerRepositoryInterface
{   
  
    protected $_customerFactory;
    protected $group;

    public function __construct(
       
        \Magento\Customer\Model\ResourceModel\Customer\CollectionFactory $customerFactory,
        \Magento\Customer\Model\Group $group
    ) {
        $this->_customerFactory = $customerFactory;
        $this->group = $group;
     
      }
      
    public function getCustomer()
    {
        $customerCollection = $this->_customerFactory->create();
        $cusGrpCode = 'Employee';
        $existingGroup =  $this->group->load($cusGrpCode, 'customer_group_code');
        $groupname = $existingGroup->getData('customer_group_id');
        $collection = $customerCollection->addFieldToFilter('group_id',['eq' => "$groupname"]);
        foreach($collection as $pro){
           
            echo "<pre>";  
            print_r($pro->getData());  
            echo"</pre>";
          
        }
        
    }
}
    