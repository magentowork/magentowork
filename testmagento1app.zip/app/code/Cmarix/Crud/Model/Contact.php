<?php
namespace Cmarix\Crud\Model;
class Contact extends \Magento\Framework\Model\AbstractModel implements \Magento\Framework\DataObject\IdentityInterface
{
	const CACHE_TAG = 'cmarix_crud';

	protected $_cacheTag = 'cmarix_crud';

	protected $_eventPrefix = 'cmarix_crud';

	protected function _construct()
	{
		$this->_init('Cmarix\Crud\Model\ResourceModel\Contact');
	}

	public function getIdentities()
	{
		return [self::CACHE_TAG . '_' . $this->getId()];
	}

	public function getDefaultValues()
	{
		$values = [];

		return $values;
	}
}
