<?php
namespace Cmarix\Crud\Model\ResourceModel\Contact;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{
	protected $_idFieldName = 'contacts_id';

	/**
	 * Define resource model
	 *
	 * @return void
	 */
	protected function _construct()
	{
		$this->_init('Cmarix\Crud\Model\Contact', 'Cmarix\Crud\Model\ResourceModel\Contact');
	}

}